#include "PluginProcessor.h"
#include "PluginEditor.h"
#include "SynthSound.h"
#include "SynthVoice.h"

//==============================================================================
AllSynthPluginAudioProcessor::AllSynthPluginAudioProcessor()
    : AudioProcessor(BusesProperties()
#if ! JucePlugin_IsMidiEffect
#if ! JucePlugin_IsSynth
                         .withInput("Input", juce::AudioChannelSet::stereo(), true)
#endif
                         .withOutput("Output", juce::AudioChannelSet::stereo(), true)
#endif
      ),
      parameters(*this, nullptr, juce::Identifier("AllSynthParams"), createParameterLayout())
{
    // Create voices and sound
    const int numVoices = 8;
    for (int i = 0; i < numVoices; ++i)
        synth.addVoice(new SynthVoice(parameters));

    synth.addSound(new SynthSound());
}

//==============================================================================
juce::AudioProcessorValueTreeState::ParameterLayout AllSynthPluginAudioProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    // Synth model selection
    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        "MODEL",
        "Synth Model",
        juce::StringArray{
            "Minimoog","Prodigy","ARP 2600","Odyssey",
            "CS-80","Jupiter-4","MS-20","Polymoog","OB-X",
            "Prophet-5","Taurus","Model D",
            "SH-101","Juno-60","MonoPoly",
            "Voyager","Prophet-6","Jupiter-8","Polysix","Matrix-12",
            "PPG Wave","OB-6","DX7","Virus","D-50",
            "Memorymoog","Minilogue","Sub 37","Nord Lead 2","Blofeld",
            "Prophet VS","Prophet-10","JX-8P","CZ-101","ESQ-1",
            "System-8","Massive","MicroFreak","Analog Four","MicroKorg",
            "TB-303","JP-8000","M1","Wavestation","JD-800",
            "Hydrasynth","PolyBrute","Matriarch","Kronos","Prophet-12",
            "OB-Xa","OB-X8",
            "Juno-106","JX-3P","Jupiter-6","Alpha Juno",
            "Grandmother","Subsequent 25","Moog One",
            "ARP Omni",
            "CS-30","AN1x",
            "Prologue","DW-8000","MS2000","Delta",
            "Rev2","Prophet X",
            "Microwave","Q",
            "Lead 4",
            "SQ-80",
            "CZ-5000",
            "System-100",
            "Poly Evolver"
            },
        0));

    // Waveforms ---------------------------------------------------------------
    params.push_back(std::make_unique<juce::AudioParameterChoice>("WAVEFORM",  "Waveform 1", juce::StringArray({"Saw","Square","Pulse","Triangle"}), 0));
    params.push_back(std::make_unique<juce::AudioParameterChoice>("WAVEFORM2", "Waveform 2", juce::StringArray({"Saw","Square","Pulse","Triangle"}), 0));

    // Osc volumes -------------------------------------------------------------
    params.push_back(std::make_unique<juce::AudioParameterFloat>("OSC1_VOLUME", "Osc 1 Vol",
                                 juce::NormalisableRange<float>(0.000f, 0.150f, 0.0001f), 0.10f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>("OSC2_VOLUME", "Osc 2 Vol",
                                 juce::NormalisableRange<float>(0.000f, 0.150f, 0.0001f), 0.10f));

    // Pulse width (used when waveform is pulse)
    params.push_back(std::make_unique<juce::AudioParameterFloat>("PULSE_WIDTH", "Pulse Width", juce::NormalisableRange<float>(0.05f, 0.95f, 0.001f), 0.5f));

    // Filter cutoff and resonance
    params.push_back(std::make_unique<juce::AudioParameterFloat>("CUTOFF", "Cutoff", juce::NormalisableRange<float>(20.0f, 20000.0f, 0.01f, 0.5f), 20000.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>("RESONANCE", "Resonance", juce::NormalisableRange<float>(0.1f, 0.95f, 0.001f, 0.5f), 0.7f));

    // LFO ---------------------------------------------------------------------
    params.push_back(std::make_unique<juce::AudioParameterBool> ("LFO_ON",   "LFO On", false));
    params.push_back(std::make_unique<juce::AudioParameterFloat>("LFO_RATE", "LFO Rate",
                                 juce::NormalisableRange<float>(0.10f,20.0f,0.01f,0.5f), 5.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>("LFO_DEPTH","LFO Depth",
                                 juce::NormalisableRange<float>(0.0f,1.0f,0.001f), 0.0f));

    // Noise & Drive ----------------------------------------------------------
    params.push_back(std::make_unique<juce::AudioParameterBool> ("NOISE_ON",  "Noise On",  false));
    params.push_back(std::make_unique<juce::AudioParameterFloat>("NOISE_MIX", "Noise Mix",
                                 juce::NormalisableRange<float>(0.0f,1.0f,0.001f), 0.0f));
    params.push_back(std::make_unique<juce::AudioParameterBool> ("DRIVE_ON",  "Drive On",   false));
    params.push_back(std::make_unique<juce::AudioParameterFloat>("DRIVE_AMT", "Drive Amt",
                                 juce::NormalisableRange<float>(0.0f,7.0f,0.01f), 3.0f));

    // ADSR envelope
    params.push_back(std::make_unique<juce::AudioParameterFloat>("ATTACK", "Attack", juce::NormalisableRange<float>(0.001f, 5.0f, 0.001f, 0.5f), 0.01f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>("DECAY", "Decay", juce::NormalisableRange<float>(0.001f, 5.0f, 0.001f, 0.5f), 0.1f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>("SUSTAIN", "Sustain", juce::NormalisableRange<float>(0.0f, 1.0f, 0.001f), 0.8f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>("RELEASE", "Release", juce::NormalisableRange<float>(0.001f, 10.0f, 0.001f, 0.5f), 0.2f));

    // Delay / Reverb ----------------------------------------------------------
    params.push_back(std::make_unique<juce::AudioParameterBool>   ("DELAY_ON",     "Delay On",  false));
    params.push_back(std::make_unique<juce::AudioParameterFloat>  ("DELAY_MIX",    "Delay Mix",
                                     juce::NormalisableRange<float>(0.0f,1.0f,0.001f), 0.3f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>  ("DELAY_TIME",   "Delay Time ms",
                                     juce::NormalisableRange<float>(1.0f,2000.0f,1.0f), 500.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>  ("DELAY_FB",     "Delay Feedback",
                                     juce::NormalisableRange<float>(0.0f,0.95f,0.001f), 0.5f));
    params.push_back(std::make_unique<juce::AudioParameterBool>   ("DELAY_SYNC",   "Delay Sync", false));
    params.push_back(std::make_unique<juce::AudioParameterBool>   ("REVERB_ON",    "Reverb On", false));
    params.push_back(std::make_unique<juce::AudioParameterFloat>  ("REVERB_MIX",   "Reverb Mix",
                                     juce::NormalisableRange<float>(0.0f,1.0f,0.001f), 0.3f));

    return { params.begin(), params.end() };
}

//==============================================================================
void AllSynthPluginAudioProcessor::prepareToPlay(double sampleRate, int samplesPerBlock)
{
    synth.setCurrentPlaybackSampleRate(sampleRate);

    for (int i = 0; i < synth.getNumVoices(); ++i)
        if (auto* v = dynamic_cast<SynthVoice*>(synth.getVoice(i)))
            v->prepare(sampleRate, samplesPerBlock, getTotalNumOutputChannels());

    // NEW FX -------------------------------------------------------------------
    const int maxDelay = int(sampleRate * 5.0);  // 5‑second max
    delayL.prepare(sampleRate, maxDelay);
    delayR.prepare(sampleRate, maxDelay);

    juce::dsp::ProcessSpec spec { sampleRate,
                                  static_cast<uint32>(samplesPerBlock),
                                  static_cast<uint32>(getTotalNumOutputChannels()) };
    reverb.prepare(spec);
    
    // Drive oversampling
    driveOS.reset();
    driveOS.initProcessing(static_cast<uint32>(samplesPerBlock));
    
    // Reset AnalogueDrive filter states
    anaDriveL.reset();
    anaDriveR.reset();
    // -------------------------------------------------------------------------
}

void AllSynthPluginAudioProcessor::releaseResources() {}

#ifndef JucePlugin_PreferredChannelConfigurations
bool AllSynthPluginAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const
{
#if JucePlugin_IsMidiEffect
    juce::ignoreUnused(layouts);
    return true;
#else
    // Must have same number of input and output channels
    if (layouts.getMainOutputChannelSet() != juce::AudioChannelSet::mono() &&
        layouts.getMainOutputChannelSet() != juce::AudioChannelSet::stereo())
        return false;

#if ! JucePlugin_IsSynth
    if (layouts.getMainOutputChannelSet() != layouts.getMainInputChannelSet())
        return false;
#endif
    return true;
#endif
}
#endif

//==============================================================================
void AllSynthPluginAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midiMessages)
{
    juce::ScopedNoDenormals noDenormals;
    buffer.clear();

    synth.renderNextBlock(buffer, midiMessages, 0, buffer.getNumSamples());

    // ----------------------  GLOBAL FX  --------------------------------------
    const bool   delayOn   = parameters.getRawParameterValue("DELAY_ON" )->load() > 0.5f;
    const bool   syncOn    = parameters.getRawParameterValue("DELAY_SYNC")->load() > 0.5f;
    const float  delayMix  = parameters.getRawParameterValue("DELAY_MIX")->load();
    const float  fb        = parameters.getRawParameterValue("DELAY_FB" )->load();
    const float  timeMsPar = parameters.getRawParameterValue("DELAY_TIME")->load();

    // ---- calc (possibly BPM‑synced) delay time ------------------------------
    double delaySeconds = timeMsPar * 0.001;
    if (syncOn)
        if (auto* ph = getPlayHead())
        {
            juce::AudioPlayHead::CurrentPositionInfo pos;
            if (ph->getCurrentPosition(pos) && pos.bpm > 0)
                delaySeconds = 60.0 / pos.bpm;          // quarter‑note
        }

    // process L & R separately
    if (delayOn)
    {
        delayL.setMix((float)delayMix);
        delayR.setMix((float)delayMix);
        delayL.setFeedback((float)fb);
        delayR.setFeedback((float)fb);
        delayL.setDelayTime((float)delaySeconds);
        delayR.setDelayTime((float)delaySeconds);

        for (int ch = 0; ch < buffer.getNumChannels(); ++ch)
        {
            juce::AudioBuffer<float> mono(1, buffer.getNumSamples());
            mono.copyFrom(0, 0, buffer, ch, 0, buffer.getNumSamples());
            (ch == 0 ? delayL : delayR).processBlock(mono);    // digital flavour
            buffer.copyFrom(ch, 0, mono, 0, 0, buffer.getNumSamples());
        }
    }

    // ----- Reverb ------------------------------------------------------------
    const bool  revOn  = parameters.getRawParameterValue("REVERB_ON")->load() > 0.5f;
    const float revMix = parameters.getRawParameterValue("REVERB_MIX")->load();
    if (revOn)
    {
        reverb.setMix(revMix);
        reverb.processBlock(buffer);
    }
    
    // ----- High-Quality Drive ---------------------------------------------------
    driveOn  = parameters.getRawParameterValue("DRIVE_ON")->load() > 0.5f;
    driveAmt = parameters.getRawParameterValue("DRIVE_AMT")->load(); // Use DRIVE_AMT

    if (driveOn)
    {
        // Update pregain for both L/R drive instances
        anaDriveL.pregain = driveAmt;
        anaDriveR.pregain = driveAmt;
        
        // Set dryWet mix based on drive amount - starting higher and increasing with drive
        // Map from drive range (0.0-7.0) to mix range (0.2-0.9)
        float mixAmount = juce::jmap(driveAmt, 0.0f, 7.0f, 0.2f, 0.9f);
        anaDriveL.dryWet = mixAmount;
        anaDriveR.dryWet = mixAmount;
        
        // Set postgain to compensate for volume - increase as drive increases
        // Map from drive range (0.0-7.0) to gain range (1.0-1.3)
        float postGain = juce::jmap(driveAmt, 0.0f, 7.0f, 1.0f, 1.3f);
        anaDriveL.postgain = postGain;
        anaDriveR.postgain = postGain;

        // Oversample -> process -> downsample
        auto block = juce::dsp::AudioBlock<float>(buffer);
        auto osBlock = driveOS.processSamplesUp(block);

        // Process each sample with the corresponding AnalogueDrive instance
        for (int ch = 0; ch < (int)osBlock.getNumChannels(); ++ch)
        {
            float* samples = osBlock.getChannelPointer(ch);
            auto& currentDrive = (ch == 0) ? anaDriveL : anaDriveR;
            
            for (int i = 0; i < (int)osBlock.getNumSamples(); ++i)
            {
                samples[i] = currentDrive.process(ch, samples[i]);
            }
        }

        driveOS.processSamplesDown(block); // back to normal rate
    }
    // -------------------------------------------------------------------------
}

//==============================================================================
juce::AudioProcessorEditor* AllSynthPluginAudioProcessor::createEditor()
{
    return new AllSynthPluginAudioProcessorEditor(*this);
}

void AllSynthPluginAudioProcessor::getStateInformation(juce::MemoryBlock& destData)
{
    auto state = parameters.copyState();
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, destData);
}

void AllSynthPluginAudioProcessor::setStateInformation(const void* data, int sizeInBytes)
{
    std::unique_ptr<juce::XmlElement> xml(getXmlFromBinary(data, sizeInBytes));
    if (xml && xml->hasTagName(parameters.state.getType()))
        parameters.replaceState(juce::ValueTree::fromXml(*xml));
}

//==============================================================================
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new AllSynthPluginAudioProcessor();
}

//==============================================================================
// NEW: Load Preset function
//==============================================================================
void AllSynthPluginAudioProcessor::loadPreset(int index)
{
    using namespace PresetData;
    if (index < 0 || index >= (int)presets.size())
        return;

    static const std::array<const char*, NumParameters> paramIDs =
    { "MODEL","WAVEFORM","WAVEFORM2","OSC1_VOLUME","OSC2_VOLUME","PULSE_WIDTH",
      "CUTOFF","RESONANCE","LFO_ON","LFO_RATE","LFO_DEPTH",
      "NOISE_ON","NOISE_MIX","DRIVE_ON","DRIVE_AMT",
      "ATTACK","DECAY","SUSTAIN","RELEASE",
      "DELAY_ON","DELAY_MIX","DELAY_TIME","DELAY_FB","DELAY_SYNC",
      "REVERB_ON","REVERB_MIX" };

    const auto& preset = presets[(size_t)index];

    for (size_t i = 0; i < paramIDs.size(); ++i)
        if (auto* rp = dynamic_cast<juce::RangedAudioParameter*>(parameters.getParameter(paramIDs[i])))
        {
            rp->beginChangeGesture();
            rp->setValueNotifyingHost(rp->convertTo0to1(preset.v[i]));
            rp->endChangeGesture();
        }
} 