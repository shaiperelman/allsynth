#include "PluginProcessor.h"
#include "PluginEditor.h"

AllSynthPluginAudioProcessorEditor::AllSynthPluginAudioProcessorEditor(AllSynthPluginAudioProcessor& p)
    : AudioProcessorEditor(&p), processor(p)
{
    auto& vts = processor.getValueTreeState();

    // --- Setup data structures ---
    struct SynthEntry { const char* name; const char* company; };
    const SynthEntry synthModels[] = {
        {"Minimoog","Moog"},{"Prodigy","Moog"},{"Taurus","Moog"},{"Model D","Moog"},{"Memorymoog","Moog"},{"Sub 37","Moog"},{"Matriarch","Moog"},
        {"ARP 2600","ARP"},{"Odyssey","ARP"},
        {"CS-80","Yamaha"},{"DX7","Yamaha"},
        {"Jupiter-4","Roland"},{"Jupiter-8","Roland"},{"SH-101","Roland"},{"Juno-60","Roland"},{"TB-303","Roland"},{"JP-8000","Roland"},{"JD-800","Roland"},
        {"M1","Korg"},{"Wavestation","Korg"},{"Kronos","Korg"},{"MS-20","Korg"},{"Polysix","Korg"},{"MonoPoly","Korg"},{"Minilogue","Korg"},{"MicroKorg","Korg"},
        {"Prophet-5","Sequential"},{"Prophet-6","Sequential"},{"Prophet-10","Sequential"},{"Prophet-12","Sequential"},{"Prophet VS","Sequential"},
        {"OB-X","Oberheim"},{"OB-6","Oberheim"},{"Matrix-12","Oberheim"},
        {"PolyBrute","Arturia"},{"MicroFreak","Arturia"},{"Analog Four","Elektron"},{"Massive","Native Instruments"},{"Nord Lead 2","Clavia"},{"Blofeld","Waldorf"},
        {"PPG Wave","PPG"},{"CZ-101","Casio"},{"ESQ-1","Ensoniq"},{"Hydrasynth","ASM"},
        {"OB-Xa","Oberheim"},{"OB-X8","Oberheim"},
        {"Juno-106","Roland"},{"JX-3P","Roland"},{"Jupiter-6","Roland"},{"Alpha Juno","Roland"},
        {"Grandmother","Moog"},{"Subsequent 25","Moog"},{"Moog One","Moog"},
        {"ARP Omni","ARP"},
        {"CS-30","Yamaha"},{"AN1x","Yamaha"},
        {"Prologue","Korg"},{"DW-8000","Korg"},{"MS2000","Korg"},{"Delta","Korg"},
        {"Rev2","Sequential"},{"Prophet X","Sequential"},
        {"Microwave","Waldorf"},{"Q","Waldorf"},
        {"Lead 4","Clavia"},
        {"SQ-80","Ensoniq"},
        {"CZ-5000","Casio"},
        {"System-100","Roland"},
        {"Poly Evolver","Sequential"},
        // --- DreamSynth models (fictional synths) ---
        {"Nebula","DreamSynth"},{"Solstice","DreamSynth"},{"Aurora","DreamSynth"},
        {"Lumina","DreamSynth"},{"Cascade","DreamSynth"},{"Polaris","DreamSynth"},
        {"Eclipse","DreamSynth"},{"Quasar","DreamSynth"},{"Helios","DreamSynth"},
        {"Meteor","DreamSynth"},
        // --- MixSynths models (hybrid inspirations) ---
        {"Fusion-84","MixSynths"},{"Velvet-CS","MixSynths"},{"PolyProphet","MixSynths"},
        {"BassMatrix","MixSynths"},{"WaveVoyager","MixSynths"},{"StringEvo","MixSynths"},
        {"MicroMass","MixSynths"},{"DigitalMoog","MixSynths"},{"HybridLead","MixSynths"},
        {"GlowPad","MixSynths"}
    };
    // build map
    for (auto& e : synthModels) companyToSynths[e.company].push_back(e.name);
    // build id map from parameter choices
    if (auto* param = dynamic_cast<juce::AudioParameterChoice*>(vts.getParameter("MODEL")))
        for (int i=0;i<param->choices.size();++i) synthIdMap[param->choices[i].toStdString()] = i+1;
    // Company dropdown
    int cid=1; for (auto& cp: companyToSynths) companyBox.addItem(cp.first, cid++);
    companyBox.onChange = [this] { updateModelList(); };
    addAndMakeVisible(companyBox);
    companyLabel.setText("Company", juce::dontSendNotification);
    companyLabel.attachToComponent(&companyBox, false);
    companyLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(companyLabel);
    addAndMakeVisible(companyUpButton);   // Make visible
    addAndMakeVisible(companyDownButton); // Make visible
    companyBox.setColour(juce::ComboBox::backgroundColourId, juce::Colour(30,30,30));
    companyBox.setColour(juce::ComboBox::textColourId, juce::Colours::white);
    companyBox.setSelectedId(1);
    // initial model list
    updateModelList();
    // --- Add model button visibility ---
    addAndMakeVisible(modelUpButton);
    addAndMakeVisible(modelDownButton);
    // ---------------------------------

    // --- Envelope Section ---
    attackSlider.setSliderStyle(juce::Slider::SliderStyle::RotaryVerticalDrag);
    attackSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 20);
    addAndMakeVisible(attackSlider);
    attackLabel.setText("Attack", juce::dontSendNotification);
    attackLabel.attachToComponent(&attackSlider, false);
    attackLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(attackLabel);
    attackAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts, "ATTACK", attackSlider);

    decaySlider.setSliderStyle(juce::Slider::SliderStyle::RotaryVerticalDrag);
    decaySlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 20);
    addAndMakeVisible(decaySlider);
    decayLabel.setText("Decay", juce::dontSendNotification);
    decayLabel.attachToComponent(&decaySlider, false);
    decayLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(decayLabel);
    decayAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts, "DECAY", decaySlider);

    sustainSlider.setSliderStyle(juce::Slider::SliderStyle::RotaryVerticalDrag);
    sustainSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 20);
    addAndMakeVisible(sustainSlider);
    sustainLabel.setText("Sustain", juce::dontSendNotification);
    sustainLabel.attachToComponent(&sustainSlider, false);
    sustainLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(sustainLabel);
    sustainAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts, "SUSTAIN", sustainSlider);

    releaseSlider.setSliderStyle(juce::Slider::SliderStyle::RotaryVerticalDrag);
    releaseSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 20);
    addAndMakeVisible(releaseSlider);
    releaseLabel.setText("Release", juce::dontSendNotification);
    releaseLabel.attachToComponent(&releaseSlider, false);
    releaseLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(releaseLabel);
    releaseAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts, "RELEASE", releaseSlider);

    // --- Filter Section ---
    cutoffSlider.setSliderStyle(juce::Slider::SliderStyle::RotaryVerticalDrag);
    cutoffSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 20);
    addAndMakeVisible(cutoffSlider);
    cutoffLabel.setText("Cutoff", juce::dontSendNotification);
    cutoffLabel.attachToComponent(&cutoffSlider, false);
    cutoffLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(cutoffLabel);
    cutoffAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts, "CUTOFF", cutoffSlider);

    resonanceSlider.setSliderStyle(juce::Slider::SliderStyle::RotaryVerticalDrag);
    resonanceSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 20);
    addAndMakeVisible(resonanceSlider);
    resonanceLabel.setText("Resonance", juce::dontSendNotification);
    resonanceLabel.attachToComponent(&resonanceSlider, false);
    resonanceLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(resonanceLabel);
    resonanceAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts, "RESONANCE", resonanceSlider);

    // --- Oscillator Section ---
    waveformBox.addItemList({"Saw", "Square", "Pulse", "Triangle"}, 1);
    addAndMakeVisible(waveformBox);
    waveformLabel.setText("Wave 1", juce::dontSendNotification);
    waveformLabel.attachToComponent(&waveformBox, false);
    waveformLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(waveformLabel);
    waveformAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(vts, "WAVEFORM", waveformBox);

    pulseWidthSlider.setSliderStyle(juce::Slider::SliderStyle::LinearHorizontal);
    pulseWidthSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 20);
    addAndMakeVisible(pulseWidthSlider);
    pulseWidthLabel.setText("Pulse Width", juce::dontSendNotification);
    pulseWidthLabel.attachToComponent(&pulseWidthSlider, false);
    pulseWidthLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(pulseWidthLabel);
    pulseWidthAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts, "PULSE_WIDTH", pulseWidthSlider);

    // --- NEW SECOND OSC -------------------------------------------------------
    waveform2Box.addItemList({"Saw","Square","Pulse","Triangle"},1);
    addAndMakeVisible(waveform2Box);
    waveform2Label.setText("Wave 2", juce::dontSendNotification);
    waveform2Label.attachToComponent(&waveform2Box,false); waveform2Label.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(waveform2Label);
    waveform2Attachment = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(vts,"WAVEFORM2",waveform2Box);

    osc1VolSlider.setSliderStyle(juce::Slider::RotaryVerticalDrag);
    osc1VolSlider.setTextBoxStyle(juce::Slider::TextBoxBelow,false,50,20);
    addAndMakeVisible(osc1VolSlider);
    osc1VolLabel.setText("Vol 1", juce::dontSendNotification);
    osc1VolLabel.attachToComponent(&osc1VolSlider,false); osc1VolLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(osc1VolLabel);
    osc1VolAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts,"OSC1_VOLUME",osc1VolSlider);

    osc2VolSlider.setSliderStyle(juce::Slider::RotaryVerticalDrag);
    osc2VolSlider.setTextBoxStyle(juce::Slider::TextBoxBelow,false,50,20);
    addAndMakeVisible(osc2VolSlider);
    osc2VolLabel.setText("Vol 2", juce::dontSendNotification);
    osc2VolLabel.attachToComponent(&osc2VolSlider,false); osc2VolLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(osc2VolLabel);
    osc2VolAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts,"OSC2_VOLUME",osc2VolSlider);

    // --- Model Section ---
    modelBox.addSectionHeading("Moog");
    modelBox.addItem("Minimoog", 1);
    modelBox.addItem("Prodigy", 2);
    modelBox.addItem("Taurus", 3);
    modelBox.addItem("Model D", 4);
    modelBox.addItem("Memorymoog", 5);
    modelBox.addItem("Sub 37", 6);
    modelBox.addItem("Matriarch", 7);
    modelBox.addSectionHeading("ARP");
    modelBox.addItem("ARP 2600", 8);
    modelBox.addItem("Odyssey", 9);
    modelBox.addSectionHeading("Yamaha");
    modelBox.addItem("CS-80", 10);
    modelBox.addItem("DX7", 11);
    modelBox.addSectionHeading("Roland");
    modelBox.addItem("Jupiter-4", 12);
    modelBox.addItem("Jupiter-8", 13);
    modelBox.addItem("SH-101", 14);
    modelBox.addItem("Juno-60", 15);
    modelBox.addItem("TB-303", 16);
    modelBox.addItem("JP-8000", 17);
    modelBox.addItem("JD-800", 18);
    modelBox.addSectionHeading("Korg");
    modelBox.addItem("M1", 19);
    modelBox.addItem("Wavestation", 20);
    modelBox.addItem("Kronos", 21);
    modelBox.addItem("MS-20", 22);
    modelBox.addItem("Polysix", 23);
    modelBox.addItem("MonoPoly", 24);
    modelBox.addItem("Minilogue", 25);
    modelBox.addItem("MicroKorg", 26);
    modelBox.addSectionHeading("Sequential");
    modelBox.addItem("Prophet-5", 27);
    modelBox.addItem("Prophet-6", 28);
    modelBox.addItem("Prophet-10", 29);
    modelBox.addItem("Prophet-12", 30);
    modelBox.addItem("Prophet VS", 31);
    modelBox.addSectionHeading("Oberheim");
    modelBox.addItem("OB-X", 32);
    modelBox.addItem("OB-6", 33);
    modelBox.addItem("Matrix-12", 34);
    modelBox.addSectionHeading("Arturia");
    modelBox.addItem("PolyBrute", 35);
    modelBox.addItem("MicroFreak", 36);
    modelBox.addSectionHeading("Elektron");
    modelBox.addItem("Analog Four", 37);
    modelBox.addSectionHeading("Native Instruments");
    modelBox.addItem("Massive", 38);
    modelBox.addSectionHeading("Clavia");
    modelBox.addItem("Nord Lead 2", 39);
    modelBox.addSectionHeading("Waldorf");
    modelBox.addItem("Blofeld", 40);
    modelBox.addSectionHeading("PPG");
    modelBox.addItem("PPG Wave", 41);
    modelBox.addSectionHeading("Casio");
    modelBox.addItem("CZ-101", 42);
    modelBox.addSectionHeading("Ensoniq");
    modelBox.addItem("ESQ-1", 43);
    modelBox.addSectionHeading("ASM");
    modelBox.addItem("Hydrasynth", 44);
    addAndMakeVisible(modelBox);
    modelLabel.setText("Synth Model", juce::dontSendNotification);
    modelLabel.attachToComponent(&modelBox, false); // Attach above
    modelLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(modelLabel);
    modelAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(vts, "MODEL", modelBox);

    // --- LFO ------------------------------------------------------------------
    lfoToggle.setButtonText("LFO");
    addAndMakeVisible(lfoToggle);
    lfoToggleAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(vts,"LFO_ON",lfoToggle);

    lfoRateSlider.setSliderStyle(juce::Slider::RotaryVerticalDrag);
    lfoRateSlider.setTextBoxStyle(juce::Slider::TextBoxBelow,false,50,20);
    addAndMakeVisible(lfoRateSlider);
    lfoRateLabel.setText("Rate", juce::dontSendNotification);
    lfoRateLabel.attachToComponent(&lfoRateSlider,false); lfoRateLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(lfoRateLabel);
    lfoRateAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts,"LFO_RATE",lfoRateSlider);

    lfoDepthSlider.setSliderStyle(juce::Slider::RotaryVerticalDrag);
    lfoDepthSlider.setTextBoxStyle(juce::Slider::TextBoxBelow,false,50,20);
    addAndMakeVisible(lfoDepthSlider);
    lfoDepthLabel.setText("Depth", juce::dontSendNotification);
    lfoDepthLabel.attachToComponent(&lfoDepthSlider,false); lfoDepthLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(lfoDepthLabel);
    lfoDepthAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts,"LFO_DEPTH",lfoDepthSlider);

    // --- Noise & Drive ---------------------------------------------------------
    noiseToggle.setButtonText("Noise");
    addAndMakeVisible(noiseToggle);
    noiseToggleAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(vts,"NOISE_ON",noiseToggle);

    noiseMixSlider.setSliderStyle(juce::Slider::RotaryVerticalDrag);
    noiseMixSlider.setTextBoxStyle(juce::Slider::TextBoxBelow,false,50,20);
    addAndMakeVisible(noiseMixSlider);
    noiseMixLabel.setText("N-Mix", juce::dontSendNotification);
    noiseMixLabel.attachToComponent(&noiseMixSlider,false);
    noiseMixLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(noiseMixLabel);
    noiseMixAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts,"NOISE_MIX",noiseMixSlider);

    driveToggle.setButtonText("Drive");
    addAndMakeVisible(driveToggle);
    driveToggleAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(vts,"DRIVE_ON",driveToggle);

    driveAmtSlider.setSliderStyle(juce::Slider::RotaryVerticalDrag);
    driveAmtSlider.setTextBoxStyle(juce::Slider::TextBoxBelow,false,50,20);
    addAndMakeVisible(driveAmtSlider);
    driveAmtLabel.setText("Drive Amt", juce::dontSendNotification);
    driveAmtLabel.attachToComponent(&driveAmtSlider,false);
    driveAmtLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(driveAmtLabel);
    driveAmtAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts,"DRIVE_AMT",driveAmtSlider);

    // ----------  PRESET UI ----------------------------------------------------
    const auto& presets = processor.getPresets();
    for (size_t i = 0; i < presets.size(); ++i)
        categoryToPresetIndices[presets[i].category].push_back((int)i);

    int cid_preset = 1;
    for (const auto& cp : categoryToPresetIndices)
        presetCategoryBox.addItem(cp.first, cid_preset++);

    presetCategoryBox.onChange = [this]{ updatePresetDropDown(); };
    addAndMakeVisible(presetCategoryBox);
    // --- Add category button visibility ---
    addAndMakeVisible(presetCategoryUpButton);
    addAndMakeVisible(presetCategoryDownButton);
    // ------------------------------------
    presetCategoryLabel.setText("Category", juce::dontSendNotification);
    presetCategoryLabel.attachToComponent(&presetCategoryBox, false);
    presetCategoryLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(presetCategoryLabel);

    addAndMakeVisible(presetBox);
    // --- Add preset button visibility ---
    addAndMakeVisible(presetUpButton);
    addAndMakeVisible(presetDownButton);
    // ----------------------------------
    presetLabel.setText("Preset", juce::dontSendNotification);
    presetLabel.attachToComponent(&presetBox, false);
    presetLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(presetLabel);

    presetBox.onChange = [this,&p=processor]
    {
        int id = presetBox.getSelectedId() - 1;     // itemId = presetIndex+1
        p.loadPreset(id);
        
        // Fix - Update company and model dropdowns to match the MODEL parameter value
        auto* modelParam = p.getValueTreeState().getParameter("MODEL");
        if (modelParam) {
            int modelValue = (int)modelParam->convertFrom0to1(modelParam->getValue());
            
            // We need to find which model name corresponds to this model value
            std::string modelName;
            for (const auto& entry : synthIdMap) {
                if (entry.second == modelValue) {
                    modelName = entry.first;
                    break;
                }
            }
            
            if (!modelName.empty()) {
                // Find which company this model belongs to
                std::string companyName;
                for (const auto& comp : companyToSynths) {
                    auto it = std::find(comp.second.begin(), comp.second.end(), modelName);
                    if (it != comp.second.end()) {
                        companyName = comp.first;
                        break;
                    }
                }
                
                if (!companyName.empty()) {
                    // Select company in the dropdown (triggers updateModelList)
                    for (int i = 1; i <= companyBox.getNumItems(); ++i) {
                        if (companyBox.getItemText(i-1).toStdString() == companyName) {
                            companyBox.setSelectedId(i, juce::sendNotification);
                            // After model list is updated, select the correct model
                            for (int j = 1; j <= modelBox.getNumItems(); ++j) {
                                if (modelBox.getItemText(j-1).toStdString() == modelName) {
                                    modelBox.setSelectedId(modelBox.getItemId(j-1), juce::dontSendNotification);
                                    break;
                                }
                            }
                            break;
                        }
                    }
                }
            }
        }
    };

    presetCategoryBox.setSelectedId(1);             // trigger initial fill

    // --- Delay / Reverb (add Time, FB, Sync controls)-------------------------
    delayToggle.setButtonText("Delay");
    addAndMakeVisible(delayToggle);
    delayToggleAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(vts,"DELAY_ON",delayToggle);

    delayMixSlider.setSliderStyle(juce::Slider::RotaryVerticalDrag);
    delayMixSlider.setTextBoxStyle(juce::Slider::TextBoxBelow,false,50,20);
    addAndMakeVisible(delayMixSlider);
    delayMixLabel.setText("D-Mix", juce::dontSendNotification);
    delayMixLabel.attachToComponent(&delayMixSlider,false);
    delayMixLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(delayMixLabel);
    delayMixAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts,"DELAY_MIX",delayMixSlider);

    delayTimeSlider.setSliderStyle(juce::Slider::RotaryVerticalDrag);
    delayTimeSlider.setTextBoxStyle(juce::Slider::TextBoxBelow,false,50,20);
    addAndMakeVisible(delayTimeSlider);
    delayTimeLabel.setText("Time", juce::dontSendNotification);
    delayTimeLabel.attachToComponent(&delayTimeSlider,false);
    delayTimeLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(delayTimeLabel);
    delayTimeAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts,"DELAY_TIME",delayTimeSlider);

    delayFeedbackSlider.setSliderStyle(juce::Slider::RotaryVerticalDrag);
    delayFeedbackSlider.setTextBoxStyle(juce::Slider::TextBoxBelow,false,50,20);
    addAndMakeVisible(delayFeedbackSlider);
    delayFbLabel.setText("FB", juce::dontSendNotification);
    delayFbLabel.attachToComponent(&delayFeedbackSlider,false);
    delayFbLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(delayFbLabel);
    delayFbAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts,"DELAY_FB",delayFeedbackSlider);

    delaySyncToggle.setButtonText("Sync");
    addAndMakeVisible(delaySyncToggle);
    delaySyncAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(vts,"DELAY_SYNC",delaySyncToggle);

    reverbToggle.setButtonText("Reverb");
    addAndMakeVisible(reverbToggle);
    reverbToggleAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(vts,"REVERB_ON",reverbToggle);

    reverbMixSlider.setSliderStyle(juce::Slider::RotaryVerticalDrag);
    reverbMixSlider.setTextBoxStyle(juce::Slider::TextBoxBelow,false,50,20);
    addAndMakeVisible(reverbMixSlider);
    reverbMixLabel.setText("R-Mix", juce::dontSendNotification);
    reverbMixLabel.attachToComponent(&reverbMixSlider,false);
    reverbMixLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(reverbMixLabel);
    reverbMixAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts,"REVERB_MIX",reverbMixSlider);

    // After creating all the sliders but before styling
    
    // Set up larger slider sizes
    const auto setupRotarySlider = [](juce::Slider& slider)
    {
        slider.setSliderStyle(juce::Slider::SliderStyle::RotaryVerticalDrag);
        slider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 60, 20);
        slider.setSize(80, 80); // Make the slider larger
    };
    
    // Apply to all rotary sliders
    for (auto* slider : {&attackSlider, &decaySlider, &sustainSlider, &releaseSlider,
                        &cutoffSlider, &resonanceSlider, 
                        &osc1VolSlider, &osc2VolSlider, 
                        &lfoRateSlider, &lfoDepthSlider,
                        &delayMixSlider, &reverbMixSlider, 
                        &delayTimeSlider, &delayFeedbackSlider,
                        &noiseMixSlider,&driveAmtSlider})
    {
        setupRotarySlider(*slider);
    }
    
    // Make the horizontal slider larger too
    pulseWidthSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 70, 20);
    
    // style
    setSize(1200, 800);
    
    // Modern UI color scheme
    const juce::Colour bgColor = juce::Colours::black;
    const juce::Colour accentColor = juce::Colour(0, 215, 187);     // Teal/cyan
    const juce::Colour secondaryColor = juce::Colour(88, 97, 224);  // Purple/blue
    const juce::Colour textColor = juce::Colour(240, 240, 240);     // Almost white
    const juce::Colour controlBgColor = juce::Colour(30, 30, 40);   // Dark blue-gray
    const juce::Colour sliderTrackColor = juce::Colour(60, 60, 70); // Lighter gray

    getLookAndFeel().setColour(juce::ResizableWindow::backgroundColourId, bgColor);
    
    // Style labels
    for (auto* lbl: {&attackLabel,&decayLabel,&sustainLabel,&releaseLabel,&cutoffLabel,&resonanceLabel,
                    &waveformLabel,&pulseWidthLabel,&companyLabel,&modelLabel,
                    &osc1VolLabel,&osc2VolLabel,&waveform2Label,&lfoRateLabel,&lfoDepthLabel,
                    &delayMixLabel,&reverbMixLabel,&delayTimeLabel,&delayFbLabel,
                    &noiseMixLabel,&driveAmtLabel,&presetCategoryLabel,&presetLabel}) {
        lbl->setColour(juce::Label::textColourId, textColor);
        lbl->setFont(juce::Font(16.0f).withStyle(juce::Font::bold));
    }
    
    // Style combo boxes
    for (auto* cb: {&companyBox,&modelBox,&waveformBox,&waveform2Box,&presetCategoryBox,&presetBox}) {
        cb->setColour(juce::ComboBox::backgroundColourId, controlBgColor);
        cb->setColour(juce::ComboBox::textColourId, textColor);
        cb->setColour(juce::ComboBox::arrowColourId, accentColor);
        cb->setColour(juce::ComboBox::outlineColourId, controlBgColor.darker(0.5f));
        cb->setColour(juce::ComboBox::buttonColourId, secondaryColor.darker(0.2f));
    }
    
    // Style toggle buttons
    for (auto* tgl: {&lfoToggle,&delayToggle,&reverbToggle,&delaySyncToggle,&noiseToggle,&driveToggle}) {
        tgl->setColour(juce::ToggleButton::textColourId, textColor);
        tgl->setColour(juce::ToggleButton::tickColourId, accentColor);
        tgl->setColour(juce::ToggleButton::tickDisabledColourId, accentColor.withAlpha(0.4f));
    }
    
    // Style sliders
    for (auto* sw: {&attackSlider,&decaySlider,&sustainSlider,&releaseSlider,
                   &cutoffSlider,&resonanceSlider,&pulseWidthSlider,
                   &osc1VolSlider,&osc2VolSlider,&lfoRateSlider,&lfoDepthSlider,
                   &delayMixSlider,&reverbMixSlider,&delayTimeSlider,&delayFeedbackSlider,
                   &noiseMixSlider,&driveAmtSlider}) {
        sw->setColour(juce::Slider::thumbColourId, accentColor);
        sw->setColour(juce::Slider::trackColourId, sliderTrackColor);
        sw->setColour(juce::Slider::rotarySliderFillColourId, secondaryColor);
        sw->setColour(juce::Slider::rotarySliderOutlineColourId, sliderTrackColor);
        sw->setColour(juce::Slider::textBoxTextColourId, textColor);
        sw->setColour(juce::Slider::textBoxOutlineColourId, controlBgColor.darker(0.5f));
        sw->setColour(juce::Slider::textBoxBackgroundColourId, controlBgColor);
    }

    // --- Button Click Logic ---
    auto setupNavButton = [](juce::ComboBox& box, juce::TextButton& upButton, juce::TextButton& downButton)
    {
        upButton.onClick = [&box]() {
            int currentId = box.getSelectedId();
            int numItems = box.getNumItems();
            if (numItems <= 1) return; // No change needed

            int currentIndex = -1;
            for(int i = 0; i < numItems; ++i) {
                if (box.getItemId(i) == currentId) {
                    currentIndex = i;
                    break;
                }
            }

            if (currentIndex != -1) {
                int nextIndex = (currentIndex - 1 + numItems) % numItems;
                box.setSelectedId(box.getItemId(nextIndex), juce::sendNotification);
            } else if (numItems > 0) { // If no valid ID selected, go to last item
                 box.setSelectedId(box.getItemId(numItems - 1), juce::sendNotification);
            }
        };

        downButton.onClick = [&box]() {
            int currentId = box.getSelectedId();
            int numItems = box.getNumItems();
            if (numItems <= 1) return; // No change needed

            int currentIndex = -1;
            for(int i = 0; i < numItems; ++i) {
                if (box.getItemId(i) == currentId) {
                    currentIndex = i;
                    break;
                }
            }

             if (currentIndex != -1) {
                int nextIndex = (currentIndex + 1) % numItems;
                box.setSelectedId(box.getItemId(nextIndex), juce::sendNotification);
            } else if (numItems > 0) { // If no valid ID selected, go to first item
                box.setSelectedId(box.getItemId(0), juce::sendNotification);
            }
        };
    };

    setupNavButton(presetCategoryBox, presetCategoryUpButton, presetCategoryDownButton);
    setupNavButton(presetBox, presetUpButton, presetDownButton);
    setupNavButton(companyBox, companyUpButton, companyDownButton);
    setupNavButton(modelBox, modelUpButton, modelDownButton);

    // --- Style new buttons ---
    for(auto* btn : {&presetCategoryUpButton, &presetCategoryDownButton, &presetUpButton, &presetDownButton,
                     &companyUpButton, &companyDownButton, &modelUpButton, &modelDownButton})
    {
        btn->setColour(juce::TextButton::buttonColourId, controlBgColor);
        btn->setColour(juce::TextButton::textColourOffId, accentColor);
        btn->setColour(juce::TextButton::textColourOnId, textColor); // Colour when pressed
    }
    // -------------------------
}

//==============================================================================
void AllSynthPluginAudioProcessorEditor::updateModelList()
{
    // Filter models by selected company
    auto compName = companyBox.getText().toStdString();
    modelBox.clear(juce::dontSendNotification);
    if (companyToSynths.count(compName) > 0) {
        for (auto& synth : companyToSynths[compName]) {
            auto it = synthIdMap.find(synth);
            if (it != synthIdMap.end())
                modelBox.addItem(synth, it->second);
        }
    }
    // Ensure first item selected
    if (modelBox.getNumItems() > 0)
        modelBox.setSelectedId(modelBox.getItemId(0), juce::dontSendNotification);
}

//==============================================================================
// NEW: update preset dropdown based on category
//==============================================================================
void AllSynthPluginAudioProcessorEditor::updatePresetDropDown()
{
    auto cat = presetCategoryBox.getText().toStdString();
    presetBox.clear(juce::dontSendNotification);

    if (categoryToPresetIndices.count(cat))
        for (int idx : categoryToPresetIndices[cat])
            presetBox.addItem(processor.getPresets()[idx].name, idx + 1);

    if (presetBox.getNumItems() > 0) {
        // First select the item without notification
        int firstItemId = presetBox.getItemId(0);
        presetBox.setSelectedId(firstItemId, juce::dontSendNotification);
        
        // Then manually load the preset
        int presetIndex = firstItemId - 1;  // ItemId = presetIndex+1
        processor.loadPreset(presetIndex);
        
        // Update company and model dropdowns to match the MODEL parameter
        auto* modelParam = processor.getValueTreeState().getParameter("MODEL");
        if (modelParam) {
            int modelValue = (int)modelParam->convertFrom0to1(modelParam->getValue());
            
            // Find which model name corresponds to this model value
            std::string modelName;
            for (const auto& entry : synthIdMap) {
                if (entry.second == modelValue) {
                    modelName = entry.first;
                    break;
                }
            }
            
            if (!modelName.empty()) {
                // Find which company this model belongs to
                std::string companyName;
                for (const auto& comp : companyToSynths) {
                    auto it = std::find(comp.second.begin(), comp.second.end(), modelName);
                    if (it != comp.second.end()) {
                        companyName = comp.first;
                        break;
                    }
                }
                
                if (!companyName.empty()) {
                    // Select company in the dropdown (triggers updateModelList)
                    for (int i = 1; i <= companyBox.getNumItems(); ++i) {
                        if (companyBox.getItemText(i-1).toStdString() == companyName) {
                            companyBox.setSelectedId(i, juce::sendNotification);
                            // After model list is updated, select the correct model
                            for (int j = 1; j <= modelBox.getNumItems(); ++j) {
                                if (modelBox.getItemText(j-1).toStdString() == modelName) {
                                    modelBox.setSelectedId(modelBox.getItemId(j-1), juce::dontSendNotification);
                                    break;
                                }
                            }
                            break;
                        }
                    }
                }
            }
        }
    }
}

// Destructor is defaulted in the header

void AllSynthPluginAudioProcessorEditor::paint(juce::Graphics& g)
{
    // Fill the background
    g.fillAll(getLookAndFeel().findColour(juce::ResizableWindow::backgroundColourId));

    // Optional: Draw some text or decorations
    g.setColour(juce::Colours::white);
    g.setFont(15.0f);
    // g.drawFittedText("AllSynth v1.0", getLocalBounds(), juce::Justification::centredTop, 1);
}

void AllSynthPluginAudioProcessorEditor::resized()
{
    auto bounds = getLocalBounds().reduced(30); // Increased margin from 25 to 30

    // Define button width and gap
    const int buttonWidth = 25;
    const int buttonGap = 5;

    // ---- Top row for presets ----
    auto presetRow = bounds.removeFromTop(70);
    auto presetHalfWidth = presetRow.getWidth() / 2;

    // Category Area (Left)
    auto categoryArea = presetRow.removeFromLeft(presetHalfWidth).reduced(20, 15);
    presetCategoryUpButton.setBounds(categoryArea.removeFromRight(buttonWidth));
    categoryArea.removeFromRight(buttonGap); // Gap
    presetCategoryDownButton.setBounds(categoryArea.removeFromRight(buttonWidth));
    categoryArea.removeFromRight(buttonGap); // Gap
    presetCategoryBox.setBounds(categoryArea);
    presetCategoryLabel.setTopLeftPosition(presetCategoryBox.getX(), presetCategoryBox.getY() - 25);

    // Preset Area (Right)
    auto presetArea = presetRow.reduced(20, 15);
    presetUpButton.setBounds(presetArea.removeFromRight(buttonWidth));
    presetArea.removeFromRight(buttonGap); // Gap
    presetDownButton.setBounds(presetArea.removeFromRight(buttonWidth));
    presetArea.removeFromRight(buttonGap); // Gap
    presetBox.setBounds(presetArea);
    presetLabel.setTopLeftPosition(presetBox.getX(), presetBox.getY() - 25);

    // Keep 4 columns, but they will be wider now
    const int columnWidth = bounds.getWidth() / 4;
    auto oscModelArea  = bounds.removeFromLeft(columnWidth);
    auto filterEnvArea = bounds.removeFromLeft(columnWidth); // Filter + Env
    auto lfoNoiseArea  = bounds.removeFromLeft(columnWidth); // LFO + Noise/Drive
    auto fxArea        = bounds;                             // Remaining width for FX

    // --- Column 1: Oscillators & Model ---
    // Allocate slightly more space relatively for controls vs labels
    auto oscSectionHeight = oscModelArea.getHeight() * 0.65f; // Increased from 0.6
    auto modelSectionHeight = oscModelArea.getHeight() * 0.35f;// Decreased from 0.4
    auto oscArea   = oscModelArea.removeFromTop(oscSectionHeight);
    auto modelArea = oscModelArea;

    // Give rows slightly more space
    auto oscRowHeight = oscArea.getHeight() / 5;
    
    // Make dropdown controls narrower by adding more horizontal padding
    auto oscPaddingX = 35; // Increase horizontal padding significantly for dropdown menus
    auto oscPaddingY = 10; // Increase vertical padding slightly
    
    // Reduce width of dropdown menus by 70% of their container
    auto dropdownWidth = oscArea.getWidth() * 0.7f;
    auto dropdownX = (oscArea.getWidth() - dropdownWidth) / 2;
    
    // Set bounds for wave dropdown menus - centered and narrower
    auto waveform1Area = oscArea.removeFromTop(oscRowHeight);
    // Make dropdown shorter - use 60% of the available height
    float dropdownHeight = waveform1Area.getHeight() * 0.6f;
    waveformBox.setBounds(waveform1Area.withSizeKeepingCentre(dropdownWidth, dropdownHeight));
    
    // Position waveform label a bit higher (with padding above the dropdown)
    waveformLabel.setTopLeftPosition(waveformBox.getX(), waveformBox.getY() - 25);
    
    auto waveform2Area = oscArea.removeFromTop(oscRowHeight);
    waveform2Box.setBounds(waveform2Area.withSizeKeepingCentre(dropdownWidth, dropdownHeight));
    
    // Position waveform2 label a bit higher as well
    waveform2Label.setTopLeftPosition(waveform2Box.getX(), waveform2Box.getY() - 25);
    
    // Place volume sliders side by side instead of stacked
    auto volumeSliderArea = oscArea.removeFromTop(oscRowHeight);
    auto volSliderHalfWidth = volumeSliderArea.getWidth() / 2;
    
    // First volume slider on the left
    osc1VolSlider.setBounds(volumeSliderArea.removeFromLeft(volSliderHalfWidth).reduced(5, oscPaddingY - 5));
    
    // Second volume slider on the right
    osc2VolSlider.setBounds(volumeSliderArea.reduced(5, oscPaddingY - 5));
    
    // Adjust osc volume slider labels (they are attached to the sliders)
    osc1VolLabel.setTopLeftPosition(osc1VolSlider.getX(), osc1VolSlider.getY() - 20);
    osc2VolLabel.setTopLeftPosition(osc2VolSlider.getX(), osc2VolSlider.getY() - 20);
    
    // Remaining space for PW slider
    pulseWidthSlider.setBounds(oscArea.reduced(oscPaddingX - 20, oscPaddingY - 5)); // PW slider
    
    // Move the pulse width label above the slider with some padding
    pulseWidthLabel.setTopLeftPosition(pulseWidthSlider.getX(), pulseWidthSlider.getY() - 5);

    // Synth model dropdowns - also narrower
    auto modelRowHeight = modelArea.getHeight() / 2;
    auto modelDropdownWidthRatio = 0.7f; // Ratio for the dropdown itself
    auto totalModelControlWidth = modelArea.getWidth() * modelDropdownWidthRatio;
    auto modelDropdownWidth = totalModelControlWidth - (2 * buttonWidth + 2 * buttonGap); // Width for ComboBox
    
    float modelDropdownHeight = modelRowHeight * 0.6f;

    auto companyAreaFull = modelArea.removeFromTop(modelRowHeight);
    auto companyControlBounds = companyAreaFull.withSizeKeepingCentre(totalModelControlWidth, modelDropdownHeight);
    companyBox.setBounds(companyControlBounds.removeFromLeft(modelDropdownWidth));
    companyControlBounds.removeFromLeft(buttonGap);
    companyUpButton.setBounds(companyControlBounds.removeFromLeft(buttonWidth));
    companyControlBounds.removeFromLeft(buttonGap);
    companyDownButton.setBounds(companyControlBounds);
    companyLabel.setTopLeftPosition(companyBox.getX(), companyBox.getY() - 25);

    auto modelAreaFull = modelArea;
    auto modelControlBounds = modelAreaFull.withSizeKeepingCentre(totalModelControlWidth, modelDropdownHeight);
    modelBox.setBounds(modelControlBounds.removeFromLeft(modelDropdownWidth));
    modelControlBounds.removeFromLeft(buttonGap);
    modelUpButton.setBounds(modelControlBounds.removeFromLeft(buttonWidth));
    modelControlBounds.removeFromLeft(buttonGap);
    modelDownButton.setBounds(modelControlBounds);
    modelLabel.setTopLeftPosition(modelBox.getX(), modelBox.getY() - 25);

    // --- Column 2: Filter & Amp Envelope ---
    auto filterSectionHeight = filterEnvArea.getHeight() * 0.30f; // Less space for filter
    auto envSectionHeight    = filterEnvArea.getHeight() * 0.70f; // More space for Env

    auto filterArea = filterEnvArea.removeFromTop(filterSectionHeight);
    auto envArea    = filterEnvArea;

    auto filterSliderWidth = filterArea.getWidth() / 2;
    auto filterPadding = 10; // Increase padding
    cutoffSlider   .setBounds(filterArea.removeFromLeft(filterSliderWidth).reduced(filterPadding));
    resonanceSlider.setBounds(filterArea.reduced(filterPadding));

    const int numEnvSliders = 4;
    auto envSliderHeight = envArea.getHeight() / numEnvSliders;
    auto envPadding = 10; // Increase padding
    attackSlider .setBounds(envArea.removeFromTop(envSliderHeight).reduced(envPadding));
    decaySlider  .setBounds(envArea.removeFromTop(envSliderHeight).reduced(envPadding));
    sustainSlider.setBounds(envArea.removeFromTop(envSliderHeight).reduced(envPadding));
    releaseSlider.setBounds(envArea.reduced(envPadding));

    // --- Column 3: LFO & Noise/Drive ---
    auto lfoSectionHeight = lfoNoiseArea.getHeight() * 0.45f; // More space for LFO
    auto noiseDriveSectionHeight = lfoNoiseArea.getHeight() * 0.55f; // More space for Noise/Drive

    auto lfoArea        = lfoNoiseArea.removeFromTop(lfoSectionHeight);
    auto noiseDriveArea = lfoNoiseArea;

    auto lfoRowHeight = lfoArea.getHeight() / 3;
    auto lfoPaddingX = 30; // More horizontal padding for toggles
    auto lfoPaddingY = 8;
    lfoToggle     .setBounds(lfoArea.removeFromTop(lfoRowHeight).reduced(lfoPaddingX, lfoPaddingY + 5)); // Extra Y padding
    lfoRateSlider .setBounds(lfoArea.removeFromTop(lfoRowHeight).reduced(envPadding)); // Reuse envPadding
    lfoDepthSlider.setBounds(lfoArea.reduced(envPadding));

    auto noiseDriveRowHeight = noiseDriveArea.getHeight() / 4;
    noiseToggle   .setBounds(noiseDriveArea.removeFromTop(noiseDriveRowHeight).reduced(lfoPaddingX, lfoPaddingY));
    noiseMixSlider.setBounds(noiseDriveArea.removeFromTop(noiseDriveRowHeight).reduced(envPadding));
    driveToggle   .setBounds(noiseDriveArea.removeFromTop(noiseDriveRowHeight).reduced(lfoPaddingX, lfoPaddingY));
    driveAmtSlider.setBounds(noiseDriveArea.reduced(envPadding));

    // --- Column 4: FX ---
    // Adjust spacing for FX controls
    const int numFxRows = 7;
    auto fxRowHeight = fxArea.getHeight() / numFxRows;
    auto fxPaddingX = 30; // More horizontal padding for toggles
    auto fxPaddingY = 8;
    auto fxSliderPadding = 10; // Padding for sliders

    delayToggle        .setBounds(fxArea.removeFromTop(fxRowHeight).reduced(fxPaddingX, fxPaddingY));
    delayMixSlider     .setBounds(fxArea.removeFromTop(fxRowHeight).reduced(fxSliderPadding));
    delayTimeSlider    .setBounds(fxArea.removeFromTop(fxRowHeight).reduced(fxSliderPadding));
    delayFeedbackSlider.setBounds(fxArea.removeFromTop(fxRowHeight).reduced(fxSliderPadding));
    delaySyncToggle    .setBounds(fxArea.removeFromTop(fxRowHeight).reduced(fxPaddingX, fxPaddingY));
    reverbToggle       .setBounds(fxArea.removeFromTop(fxRowHeight).reduced(fxPaddingX, fxPaddingY));
    reverbMixSlider    .setBounds(fxArea.reduced(fxSliderPadding));
}
