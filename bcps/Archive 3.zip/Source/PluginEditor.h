#pragma once

#include <JuceHeader.h>
#include "PluginProcessor.h"
#include <map>
#include <unordered_map>
#include <vector>
#include <string>

class AllSynthPluginAudioProcessorEditor : public juce::AudioProcessorEditor
{
public:
    explicit AllSynthPluginAudioProcessorEditor(AllSynthPluginAudioProcessor&);
    ~AllSynthPluginAudioProcessorEditor() override = default;

    void paint(juce::Graphics&) override;
    void resized() override;

private:
    AllSynthPluginAudioProcessor& processor;

    // UI controls
    juce::Slider attackSlider, decaySlider, sustainSlider, releaseSlider;
    juce::Slider cutoffSlider, resonanceSlider;
    juce::ComboBox waveformBox, waveform2Box;  // 2nd osc selector
    juce::Slider pulseWidthSlider;
    // Volumes
    juce::Slider osc1VolSlider, osc2VolSlider;
    juce::ComboBox modelBox;
    juce::ComboBox companyBox;
    // LFO
    juce::ToggleButton lfoToggle;
    juce::Slider       lfoRateSlider, lfoDepthSlider;
    // Noise & Drive
    juce::ToggleButton noiseToggle, driveToggle;
    juce::Slider       noiseMixSlider, driveAmtSlider;
    // FX
    juce::ToggleButton delayToggle, reverbToggle, delaySyncToggle;
    juce::Slider       delayMixSlider, reverbMixSlider, delayTimeSlider, delayFeedbackSlider;

    // --- NEW: Preset selectors -----------------------------------------------
    juce::ComboBox presetCategoryBox, presetBox;
    juce::Label    presetCategoryLabel, presetLabel;
    // --- NEW: Arrow buttons ---
    juce::TextButton presetCategoryUpButton{ "^" }, presetCategoryDownButton{ "v" };
    juce::TextButton presetUpButton{ "^" }, presetDownButton{ "v" };
    juce::TextButton companyUpButton{ "^" }, companyDownButton{ "v" };
    juce::TextButton modelUpButton{ "^" }, modelDownButton{ "v" };
    // --------------------------

    // Labels
    juce::Label attackLabel, decayLabel, sustainLabel, releaseLabel;
    juce::Label cutoffLabel, resonanceLabel, waveformLabel, pulseWidthLabel, modelLabel;
    juce::Label companyLabel;
    juce::Label osc1VolLabel, osc2VolLabel, waveform2Label;
    juce::Label lfoRateLabel, lfoDepthLabel, delayMixLabel, reverbMixLabel,
                delayTimeLabel, delayFbLabel;
    juce::Label noiseMixLabel, driveAmtLabel;

    // Attachments (unique_ptr)
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> attackAttachment, decayAttachment, sustainAttachment, releaseAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> cutoffAttachment, resonanceAttachment, pulseWidthAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> waveformAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> modelAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> osc1VolAttachment, osc2VolAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> waveform2Attachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>  lfoToggleAttachment, delayToggleAttachment, reverbToggleAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>  lfoRateAttachment, lfoDepthAttachment,
                                                                          delayMixAttachment, reverbMixAttachment,
                                                                          delayTimeAttachment, delayFbAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>  delaySyncAttachment;
    
    // Noise & Drive attachments
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>  noiseToggleAttachment, driveToggleAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>  noiseMixAttachment, driveAmtAttachment;

    // Map of companies to synths and ID map
    std::map<std::string, std::vector<std::string>> companyToSynths;
    std::unordered_map<std::string, int> synthIdMap;

    // NEW ----------------------------------------------------------------------
    std::map<std::string, std::vector<int>> categoryToPresetIndices;
    void updatePresetDropDown();
    // -------------------------------------------------------------------------

    void updateModelList();

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(AllSynthPluginAudioProcessorEditor)
}; 