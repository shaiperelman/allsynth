#include "PluginProcessor.h"
#include "PluginEditor.h"

AllSynthPluginAudioProcessorEditor::AllSynthPluginAudioProcessorEditor(AllSynthPluginAudioProcessor& p)
    : AudioProcessorEditor(&p), processor(p)
{
    auto& vts = processor.getValueTreeState();

    // --- Setup data structures ---
    struct SynthEntry { const char* name; const char* company; };
    const SynthEntry synthModels[] = {
        {"Minimoog","Moog"},{"Prodigy","Moog"},{"Taurus","Moog"},{"Model D","Moog"},{"Memorymoog","Moog"},{"Sub 37","Moog"},{"Matriarch","Moog"},
        {"ARP 2600","ARP"},{"Odyssey","ARP"},
        {"CS-80","Yamaha"},{"DX7","Yamaha"},
        {"Jupiter-4","Roland"},{"Jupiter-8","Roland"},{"SH-101","Roland"},{"Juno-60","Roland"},{"TB-303","Roland"},{"JP-8000","Roland"},{"JD-800","Roland"},
        {"M1","Korg"},{"Wavestation","Korg"},{"Kronos","Korg"},{"MS-20","Korg"},{"Polysix","Korg"},{"MonoPoly","Korg"},{"Minilogue","Korg"},{"MicroKorg","Korg"},
        {"Prophet-5","Sequential"},{"Prophet-6","Sequential"},{"Prophet-10","Sequential"},{"Prophet-12","Sequential"},{"Prophet VS","Sequential"},
        {"OB-X","Oberheim"},{"OB-6","Oberheim"},{"Matrix-12","Oberheim"},
        {"PolyBrute","Arturia"},{"MicroFreak","Arturia"},{"Analog Four","Elektron"},{"Massive","Native Instruments"},{"Nord Lead 2","Clavia"},{"Blofeld","Waldorf"},
        {"PPG Wave","PPG"},{"CZ-101","Casio"},{"ESQ-1","Ensoniq"},{"Hydrasynth","ASM"},
        {"OB-Xa","Oberheim"},{"OB-X8","Oberheim"},
        {"Juno-106","Roland"},{"JX-3P","Roland"},{"Jupiter-6","Roland"},{"Alpha Juno","Roland"},
        {"Grandmother","Moog"},{"Subsequent 25","Moog"},{"Moog One","Moog"},
        {"ARP Omni","ARP"},
        {"CS-30","Yamaha"},{"AN1x","Yamaha"},
        {"Prologue","Korg"},{"DW-8000","Korg"},{"MS2000","Korg"},{"Delta","Korg"},
        {"Rev2","Sequential"},{"Prophet X","Sequential"},
        {"Microwave","Waldorf"},{"Q","Waldorf"},
        {"Lead 4","Clavia"},
        {"SQ-80","Ensoniq"},
        {"CZ-5000","Casio"},
        {"System-100","Roland"},
        {"Poly Evolver","Sequential"},
        // --- DreamSynth models (fictional synths) ---
        {"Nebula","DreamSynth"},{"Solstice","DreamSynth"},{"Aurora","DreamSynth"},
        {"Lumina","DreamSynth"},{"Cascade","DreamSynth"},{"Polaris","DreamSynth"},
        {"Eclipse","DreamSynth"},{"Quasar","DreamSynth"},{"Helios","DreamSynth"},
        {"Meteor","DreamSynth"},
        // --- MixSynths models (hybrid inspirations) ---
        {"Fusion-84","MixSynths"},{"Velvet-CS","MixSynths"},{"PolyProphet","MixSynths"},
        {"BassMatrix","MixSynths"},{"WaveVoyager","MixSynths"},{"StringEvo","MixSynths"},
        {"MicroMass","MixSynths"},{"DigitalMoog","MixSynths"},{"HybridLead","MixSynths"},
        {"GlowPad","MixSynths"}
    };
    // build map
    for (auto& e : synthModels) companyToSynths[e.company].push_back(e.name);
    // build id map from parameter choices
    if (auto* param = dynamic_cast<juce::AudioParameterChoice*>(vts.getParameter("MODEL")))
        for (int i=0;i<param->choices.size();++i) synthIdMap[param->choices[i].toStdString()] = i;
    // Company dropdown
    int cid=1; for (auto& cp: companyToSynths) companyBox.addItem(cp.first, cid++);
    companyBox.onChange = [this] { updateModelList(); };
    addAndMakeVisible(companyBox);
    companyLabel.setText("Company", juce::dontSendNotification);
    companyLabel.attachToComponent(&companyBox, false);
    companyLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(companyLabel);
    addAndMakeVisible(companyUpButton);   // Make visible
    addAndMakeVisible(companyDownButton); // Make visible
    companyBox.setColour(juce::ComboBox::backgroundColourId, juce::Colour(30,30,30));
    companyBox.setColour(juce::ComboBox::textColourId, juce::Colours::white);
    companyBox.setSelectedId(1);
    // initial model list
    updateModelList();
    // --- Add model button visibility ---
    addAndMakeVisible(modelUpButton);
    addAndMakeVisible(modelDownButton);
    // --- NEW: Add onClick handlers for model buttons ---
    modelUpButton.onClick = [this] {
        const int numItems = modelBox.getNumItems();
        if (numItems <= 1) return;
        int currentId = modelBox.getSelectedId();
        int currentIndex = -1;
        for (int i = 0; i < numItems; ++i) {
            if (modelBox.getItemId(i) == currentId) {
                currentIndex = i;
                break;
            }
        }
        if (currentIndex != -1) {
            int prevIndex = (currentIndex - 1 + numItems) % numItems;
            // Manually trigger parameter update for model change
            if (auto* param = processor.getValueTreeState().getParameter("MODEL")) {
                 auto* choiceParam = dynamic_cast<juce::AudioParameterChoice*>(param);
                 if (choiceParam) {
                     int newModelIndex = modelBox.getItemId(prevIndex) - 1; // Item ID is index + 1
                     // Ensure the index is valid for the parameter choices
                     if (newModelIndex >= 0 && newModelIndex < choiceParam->choices.size()) {
                         choiceParam->beginChangeGesture();
                         choiceParam->setValueNotifyingHost(choiceParam->convertTo0to1(newModelIndex));
                         choiceParam->endChangeGesture();
                         // Update the ComboBox selection without triggering its own onChange
                         modelBox.setSelectedId(modelBox.getItemId(prevIndex), juce::dontSendNotification);
                     }
                 }
            }
        }
    };
    modelDownButton.onClick = [this] {
        const int numItems = modelBox.getNumItems();
        if (numItems <= 1) return;
        int currentId = modelBox.getSelectedId();
        int currentIndex = -1;
        for (int i = 0; i < numItems; ++i) {
            if (modelBox.getItemId(i) == currentId) {
                currentIndex = i;
                break;
            }
        }
        if (currentIndex != -1) {
            int nextIndex = (currentIndex + 1) % numItems;
            // Manually trigger parameter update for model change
            if (auto* param = processor.getValueTreeState().getParameter("MODEL")) {
                 auto* choiceParam = dynamic_cast<juce::AudioParameterChoice*>(param);
                 if (choiceParam) {
                     int newModelIndex = modelBox.getItemId(nextIndex) - 1; // Item ID is index + 1
                     // Ensure the index is valid for the parameter choices
                     if (newModelIndex >= 0 && newModelIndex < choiceParam->choices.size()) {
                         choiceParam->beginChangeGesture();
                         choiceParam->setValueNotifyingHost(choiceParam->convertTo0to1(newModelIndex));
                         choiceParam->endChangeGesture();
                         // Update the ComboBox selection without triggering its own onChange
                         modelBox.setSelectedId(modelBox.getItemId(nextIndex), juce::dontSendNotification);
                     }
                 }
            }
        }
    };
    // -----------------------------------------------
    // --- Add company button visibility ---
    addAndMakeVisible(companyUpButton);
    addAndMakeVisible(companyDownButton);
    // --- NEW: Add onClick handlers for company buttons ---
    companyUpButton.onClick = [this] {
        const int numItems = companyBox.getNumItems();
        if (numItems <= 1) return;
        int currentId = companyBox.getSelectedId();
        int currentIndex = -1;
        for (int i = 0; i < numItems; ++i) {
            // JUCE ComboBox IDs start at 1, but getItemId index is 0-based
            if (companyBox.getItemId(i) == currentId) {
                currentIndex = i;
                break;
            }
        }
        if (currentIndex != -1) {
            int prevIndex = (currentIndex - 1 + numItems) % numItems;
            companyBox.setSelectedId(companyBox.getItemId(prevIndex), juce::sendNotification);
        }
    };
    companyDownButton.onClick = [this] {
        const int numItems = companyBox.getNumItems();
        if (numItems <= 1) return;
        int currentId = companyBox.getSelectedId();
        int currentIndex = -1;
         for (int i = 0; i < numItems; ++i) {
            // JUCE ComboBox IDs start at 1, but getItemId index is 0-based
            if (companyBox.getItemId(i) == currentId) {
                currentIndex = i;
                break;
            }
        }
        if (currentIndex != -1) {
            int nextIndex = (currentIndex + 1) % numItems;
            companyBox.setSelectedId(companyBox.getItemId(nextIndex), juce::sendNotification);
        }
    };
    // -----------------------------------------------------

    // --- Envelope Section ---
    attackSlider.setSliderStyle(juce::Slider::SliderStyle::RotaryVerticalDrag);
    attackSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 20);
    addAndMakeVisible(attackSlider);
    attackLabel.setText("Attack", juce::dontSendNotification);
    attackLabel.attachToComponent(&attackSlider, false);
    attackLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(attackLabel);
    attackAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts, "ATTACK", attackSlider);

    decaySlider.setSliderStyle(juce::Slider::SliderStyle::RotaryVerticalDrag);
    decaySlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 20);
    addAndMakeVisible(decaySlider);
    decayLabel.setText("Decay", juce::dontSendNotification);
    decayLabel.attachToComponent(&decaySlider, false);
    decayLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(decayLabel);
    decayAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts, "DECAY", decaySlider);

    sustainSlider.setSliderStyle(juce::Slider::SliderStyle::RotaryVerticalDrag);
    sustainSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 20);
    addAndMakeVisible(sustainSlider);
    sustainLabel.setText("Sustain", juce::dontSendNotification);
    sustainLabel.attachToComponent(&sustainSlider, false);
    sustainLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(sustainLabel);
    sustainAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts, "SUSTAIN", sustainSlider);

    releaseSlider.setSliderStyle(juce::Slider::SliderStyle::RotaryVerticalDrag);
    releaseSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 20);
    addAndMakeVisible(releaseSlider);
    releaseLabel.setText("Release", juce::dontSendNotification);
    releaseLabel.attachToComponent(&releaseSlider, false);
    releaseLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(releaseLabel);
    releaseAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts, "RELEASE", releaseSlider);

    // --- Filter Section ---
    cutoffSlider.setSliderStyle(juce::Slider::SliderStyle::RotaryVerticalDrag);
    cutoffSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 20);
    addAndMakeVisible(cutoffSlider);
    cutoffLabel.setText("Cutoff", juce::dontSendNotification);
    cutoffLabel.attachToComponent(&cutoffSlider, false);
    cutoffLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(cutoffLabel);
    cutoffAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts, "CUTOFF", cutoffSlider);

    resonanceSlider.setSliderStyle(juce::Slider::SliderStyle::RotaryVerticalDrag);
    resonanceSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 20);
    addAndMakeVisible(resonanceSlider);
    resonanceLabel.setText("Resonance", juce::dontSendNotification);
    resonanceLabel.attachToComponent(&resonanceSlider, false);
    resonanceLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(resonanceLabel);
    resonanceAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts, "RESONANCE", resonanceSlider);

    // --- Oscillator Section ---
    waveformBox.addItemList({"Saw", "Square", "Pulse", "Triangle", "Sine"}, 1);
    addAndMakeVisible(waveformBox);
    waveformLabel.setText("Wave 1", juce::dontSendNotification);
    waveformLabel.attachToComponent(&waveformBox, false);
    waveformLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(waveformLabel);
    waveformAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(vts, "WAVEFORM", waveformBox);

    pulseWidthSlider.setSliderStyle(juce::Slider::SliderStyle::LinearHorizontal);
    pulseWidthSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 20);
    addAndMakeVisible(pulseWidthSlider);
    pulseWidthLabel.setText("Pulse Width", juce::dontSendNotification);
    pulseWidthLabel.attachToComponent(&pulseWidthSlider, false);
    pulseWidthLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(pulseWidthLabel);
    pulseWidthAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts, "PULSE_WIDTH", pulseWidthSlider);

    // --- NEW SECOND OSC -------------------------------------------------------
    waveform2Box.addItemList({"Saw","Square","Pulse","Triangle","Sine"},1);
    addAndMakeVisible(waveform2Box);
    waveform2Label.setText("Wave 2", juce::dontSendNotification);
    waveform2Label.attachToComponent(&waveform2Box,false); waveform2Label.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(waveform2Label);
    waveform2Attachment = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(vts,"WAVEFORM2",waveform2Box);

    osc1VolSlider.setSliderStyle(juce::Slider::RotaryVerticalDrag);
    osc1VolSlider.setTextBoxStyle(juce::Slider::TextBoxBelow,false,50,20);
    addAndMakeVisible(osc1VolSlider);
    osc1VolLabel.setText("Vol 1", juce::dontSendNotification);
    osc1VolLabel.attachToComponent(&osc1VolSlider,false); osc1VolLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(osc1VolLabel);
    osc1VolAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts,"OSC1_VOLUME",osc1VolSlider);

    osc2VolSlider.setSliderStyle(juce::Slider::RotaryVerticalDrag);
    osc2VolSlider.setTextBoxStyle(juce::Slider::TextBoxBelow,false,50,20);
    addAndMakeVisible(osc2VolSlider);
    osc2VolLabel.setText("Vol 2", juce::dontSendNotification);
    osc2VolLabel.attachToComponent(&osc2VolSlider,false); osc2VolLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(osc2VolLabel);
    osc2VolAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts,"OSC2_VOLUME",osc2VolSlider);

    // --- NEW: Coarse & Fine Tuning ---
    osc2DetuneSlider.setSliderStyle(juce::Slider::RotaryVerticalDrag);
    osc2DetuneSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 20);
    osc2DetuneSlider.setRange(-24.0, 24.0, 1.0);  // Force integer steps
    osc2DetuneSlider.setTextValueSuffix(" st");   // Show "st" for semitones
    osc2DetuneSlider.setNumDecimalPlacesToDisplay(0);  // Show only whole numbers
    addAndMakeVisible(osc2DetuneSlider);
    osc2DetuneLabel.setText("Detune", juce::dontSendNotification);
    osc2DetuneLabel.attachToComponent(&osc2DetuneSlider, false);
    osc2DetuneLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(osc2DetuneLabel);
    osc2DetuneAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts, "OSC2_DETUNE", osc2DetuneSlider);

    osc1FineSlider.setSliderStyle(juce::Slider::RotaryVerticalDrag);
    osc1FineSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 20);
    addAndMakeVisible(osc1FineSlider);
    osc1FineLabel.setText("Fine 1", juce::dontSendNotification);
    osc1FineLabel.attachToComponent(&osc1FineSlider, false);
    osc1FineLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(osc1FineLabel);
    osc1FineAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts, "OSC1_FINE", osc1FineSlider);

    osc2FineSlider.setSliderStyle(juce::Slider::RotaryVerticalDrag);
    osc2FineSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 20);
    addAndMakeVisible(osc2FineSlider);
    osc2FineLabel.setText("Fine 2", juce::dontSendNotification);
    osc2FineLabel.attachToComponent(&osc2FineSlider, false);
    osc2FineLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(osc2FineLabel);
    osc2FineAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts, "OSC2_FINE", osc2FineSlider);

    // --- NEW : Oscillator Sync toggle ----------------------------------------
    oscSyncToggle.setButtonText("Sync");
    addAndMakeVisible(oscSyncToggle);
    oscSyncAttachment = std::make_unique<
        juce::AudioProcessorValueTreeState::ButtonAttachment>(vts,
                                                              "OSC_SYNC",
                                                              oscSyncToggle);
    // -------------------------------------------------------------------------
    // ---------------------------------

    // --- Model Section ---
    modelBox.addSectionHeading("Moog");
    modelBox.addItem("Minimoog", 1);
    modelBox.addItem("Prodigy", 2);
    modelBox.addItem("Taurus", 3);
    modelBox.addItem("Model D", 4);
    modelBox.addItem("Memorymoog", 5);
    modelBox.addItem("Sub 37", 6);
    modelBox.addItem("Matriarch", 7);
    modelBox.addSectionHeading("ARP");
    modelBox.addItem("ARP 2600", 8);
    modelBox.addItem("Odyssey", 9);
    modelBox.addSectionHeading("Yamaha");
    modelBox.addItem("CS-80", 10);
    modelBox.addItem("DX7", 11);
    modelBox.addSectionHeading("Roland");
    modelBox.addItem("Jupiter-4", 12);
    modelBox.addItem("Jupiter-8", 13);
    modelBox.addItem("SH-101", 14);
    modelBox.addItem("Juno-60", 15);
    modelBox.addItem("TB-303", 16);
    modelBox.addItem("JP-8000", 17);
    modelBox.addItem("JD-800", 18);
    modelBox.addSectionHeading("Korg");
    modelBox.addItem("M1", 19);
    modelBox.addItem("Wavestation", 20);
    modelBox.addItem("Kronos", 21);
    modelBox.addItem("MS-20", 22);
    modelBox.addItem("Polysix", 23);
    modelBox.addItem("MonoPoly", 24);
    modelBox.addItem("Minilogue", 25);
    modelBox.addItem("MicroKorg", 26);
    modelBox.addSectionHeading("Sequential");
    modelBox.addItem("Prophet-5", 27);
    modelBox.addItem("Prophet-6", 28);
    modelBox.addItem("Prophet-10", 29);
    modelBox.addItem("Prophet-12", 30);
    modelBox.addItem("Prophet VS", 31);
    modelBox.addSectionHeading("Oberheim");
    modelBox.addItem("OB-X", 32);
    modelBox.addItem("OB-6", 33);
    modelBox.addItem("Matrix-12", 34);
    modelBox.addSectionHeading("Arturia");
    modelBox.addItem("PolyBrute", 35);
    modelBox.addItem("MicroFreak", 36);
    modelBox.addSectionHeading("Elektron");
    modelBox.addItem("Analog Four", 37);
    modelBox.addSectionHeading("Native Instruments");
    modelBox.addItem("Massive", 38);
    modelBox.addSectionHeading("Clavia");
    modelBox.addItem("Nord Lead 2", 39);
    modelBox.addSectionHeading("Waldorf");
    modelBox.addItem("Blofeld", 40);
    modelBox.addSectionHeading("PPG");
    modelBox.addItem("PPG Wave", 41);
    modelBox.addSectionHeading("Casio");
    modelBox.addItem("CZ-101", 42);
    modelBox.addSectionHeading("Ensoniq");
    modelBox.addItem("ESQ-1", 43);
    modelBox.addSectionHeading("ASM");
    modelBox.addItem("Hydrasynth", 44);
    addAndMakeVisible(modelBox);
    modelLabel.setText("Synth Model", juce::dontSendNotification);
    modelLabel.attachToComponent(&modelBox, false); // Attach above
    modelLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(modelLabel);
    modelAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(vts, "MODEL", modelBox);

    // --- LFO ------------------------------------------------------------------
    lfoToggle.setButtonText("LFO");
    addAndMakeVisible(lfoToggle);
    lfoToggleAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(vts,"LFO_ON",lfoToggle);

    lfoRateSlider.setSliderStyle(juce::Slider::RotaryVerticalDrag);
    lfoRateSlider.setTextBoxStyle(juce::Slider::TextBoxBelow,false,50,20);
    addAndMakeVisible(lfoRateSlider);
    lfoRateLabel.setText("Rate", juce::dontSendNotification);
    lfoRateLabel.attachToComponent(&lfoRateSlider,false); lfoRateLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(lfoRateLabel);
    lfoRateAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts,"LFO_RATE",lfoRateSlider);

    lfoDepthSlider.setSliderStyle(juce::Slider::RotaryVerticalDrag);
    lfoDepthSlider.setTextBoxStyle(juce::Slider::TextBoxBelow,false,50,20);
    addAndMakeVisible(lfoDepthSlider);
    lfoDepthLabel.setText("Depth", juce::dontSendNotification);
    lfoDepthLabel.attachToComponent(&lfoDepthSlider,false); lfoDepthLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(lfoDepthLabel);
    lfoDepthAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts,"LFO_DEPTH",lfoDepthSlider);

    // --- Noise & Drive ---------------------------------------------------------
    noiseToggle.setButtonText("Noise");
    addAndMakeVisible(noiseToggle);
    noiseToggleAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(vts,"NOISE_ON",noiseToggle);

    noiseMixSlider.setSliderStyle(juce::Slider::RotaryVerticalDrag);
    noiseMixSlider.setTextBoxStyle(juce::Slider::TextBoxBelow,false,50,20);
    addAndMakeVisible(noiseMixSlider);
    noiseMixLabel.setText("N-Mix", juce::dontSendNotification);
    noiseMixLabel.attachToComponent(&noiseMixSlider,false);
    noiseMixLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(noiseMixLabel);
    noiseMixAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts,"NOISE_MIX",noiseMixSlider);

    driveToggle.setButtonText("Drive");
    addAndMakeVisible(driveToggle);
    driveToggleAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(vts,"DRIVE_ON",driveToggle);

    driveAmtSlider.setSliderStyle(juce::Slider::RotaryVerticalDrag);
    driveAmtSlider.setTextBoxStyle(juce::Slider::TextBoxBelow,false,50,20);
    addAndMakeVisible(driveAmtSlider);
    driveAmtLabel.setText("Drive Amt", juce::dontSendNotification);
    driveAmtLabel.attachToComponent(&driveAmtSlider,false);
    driveAmtLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(driveAmtLabel);
    driveAmtAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts,"DRIVE_AMT",driveAmtSlider);

    // --- Console toggle --------------------------------------------------------
    consoleToggle.setButtonText("Fat On");
    addAndMakeVisible(consoleToggle);
    consoleToggleAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(vts,"CONSOLE_ON",consoleToggle);

    // NEW:  Pre‑amp model selector ---------------------------------------------
    consoleModelBox.addItemList({ "Tape Thick","Warm Tube","Deep Console",
                                  "Punch Glue","Sub Boom","Opto Smooth",
                                  "Tube Crunch","X-Former Fat","Bus Glue",
                                  "Vintage Tape","Neve 1073","API 312/550A",
                                  "Helios 69","Studer A80","EMI TG12345",
                                  "SSL 4K-Bus","LA-2A","Fairchild 670",
                                  "Pultec EQP-1A","Quad-Eight",
                                  "Harrison 32","MCI JH-636",
                                  "API 2500","Ampex 440","Moog Ladder Out" }, 1);
    addAndMakeVisible(consoleModelBox);
    consoleModelLabel.setText("Mode", juce::dontSendNotification);
    consoleModelAttachment = std::make_unique<
        juce::AudioProcessorValueTreeState::ComboBoxAttachment>(vts,
                                                                "CONSOLE_MODEL", consoleModelBox);

    // ----------  PRESET UI ----------------------------------------------------
    const auto& presets = processor.getPresets();
    for (size_t i = 0; i < presets.size(); ++i)
        categoryToPresetIndices[presets[i].category].push_back((int)i);

    int cid_preset = 1;
    for (const auto& cp : categoryToPresetIndices)
        presetCategoryBox.addItem(cp.first, cid_preset++);

    presetCategoryBox.onChange = [this]{ updatePresetDropDown(true); };
    addAndMakeVisible(presetCategoryBox);
    // --- Add category button visibility ---
    addAndMakeVisible(presetCategoryUpButton);
    addAndMakeVisible(presetCategoryDownButton);
    // --- NEW: Add onClick handlers for category buttons ---
    presetCategoryUpButton.onClick = [this] {
        const int numItems = presetCategoryBox.getNumItems();
        if (numItems <= 1) return;
        int currentId = presetCategoryBox.getSelectedId();
        int currentIndex = -1;
        for (int i = 0; i < numItems; ++i) {
            if (presetCategoryBox.getItemId(i) == currentId) {
                currentIndex = i;
                break;
            }
        }
        if (currentIndex != -1) {
            int prevIndex = (currentIndex - 1 + numItems) % numItems;
            presetCategoryBox.setSelectedId(presetCategoryBox.getItemId(prevIndex), juce::sendNotification);
        }
    };
    presetCategoryDownButton.onClick = [this] {
        const int numItems = presetCategoryBox.getNumItems();
        if (numItems <= 1) return;
        int currentId = presetCategoryBox.getSelectedId();
        int currentIndex = -1;
        for (int i = 0; i < numItems; ++i) {
            if (presetCategoryBox.getItemId(i) == currentId) {
                currentIndex = i;
                break;
            }
        }
        if (currentIndex != -1) {
            int nextIndex = (currentIndex + 1) % numItems;
            presetCategoryBox.setSelectedId(presetCategoryBox.getItemId(nextIndex), juce::sendNotification);
        }
    };
    // -----------------------------------------------------
    presetCategoryLabel.setText("Category", juce::dontSendNotification);
    presetCategoryLabel.attachToComponent(&presetCategoryBox, false);
    addAndMakeVisible(presetCategoryLabel);

    addAndMakeVisible(presetBox);
    // --- Add preset button visibility ---
    addAndMakeVisible(presetUpButton);
    addAndMakeVisible(presetDownButton);
    // --- NEW: Add onClick handlers for preset buttons ---
    presetUpButton.onClick = [this] {
        const int numItems = presetBox.getNumItems();
        if (numItems <= 1) return;
        int currentId = presetBox.getSelectedId();
        int currentIndex = -1;
        for (int i = 0; i < numItems; ++i) {
            if (presetBox.getItemId(i) == currentId) {
                currentIndex = i;
                break;
            }
        }
        if (currentIndex != -1) {
            int prevIndex = (currentIndex - 1 + numItems) % numItems;
            presetBox.setSelectedId(presetBox.getItemId(prevIndex), juce::sendNotification);
        }
    };
    presetDownButton.onClick = [this] {
        const int numItems = presetBox.getNumItems();
        if (numItems <= 1) return;
        int currentId = presetBox.getSelectedId();
        int currentIndex = -1;
        for (int i = 0; i < numItems; ++i) {
            if (presetBox.getItemId(i) == currentId) {
                currentIndex = i;
                break;
            }
        }
        if (currentIndex != -1) {
            int nextIndex = (currentIndex + 1) % numItems;
            presetBox.setSelectedId(presetBox.getItemId(nextIndex), juce::sendNotification);
        }
    };
    // ------------------------------------------------
    presetLabel.setText("Preset", juce::dontSendNotification);
    presetLabel.attachToComponent(&presetBox, false);
    presetLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(presetLabel);

    presetBox.onChange = [this,&p=processor]
    {
        int id = presetBox.getSelectedId() - 1;     // itemId = presetIndex+1
        p.loadPreset(id);
        
        // Fix - Update company and model dropdowns to match the MODEL parameter value
        auto* modelParam = p.getValueTreeState().getParameter("MODEL");
        if (modelParam) {
            int modelValue = (int)modelParam->convertFrom0to1(modelParam->getValue());
            
            // We need to find which model name corresponds to this model value
            std::string modelName;
            for (const auto& entry : synthIdMap) {
                if (entry.second == modelValue) {
                    modelName = entry.first;
                    break;
                }
            }
            
            if (!modelName.empty()) {
                // Find which company this model belongs to
                std::string companyName;
                for (const auto& comp : companyToSynths) {
                    auto it = std::find(comp.second.begin(), comp.second.end(), modelName);
                    if (it != comp.second.end()) {
                        companyName = comp.first;
                        break;
                    }
                }
                
                if (!companyName.empty()) {
                    // Select company in the dropdown (triggers updateModelList)
                    for (int i = 1; i <= companyBox.getNumItems(); ++i) {
                        if (companyBox.getItemText(i-1).toStdString() == companyName) {
                            companyBox.setSelectedId(i, juce::sendNotification);
                            // After model list is updated, select the correct model
                            for (int j = 1; j <= modelBox.getNumItems(); ++j) {
                                if (modelBox.getItemText(j-1).toStdString() == modelName) {
                                    modelBox.setSelectedId(modelBox.getItemId(j-1), juce::dontSendNotification);
                                    break;
                                }
                            }
                            break;
                        }
                    }
                }
            }
        }
    };

    presetCategoryBox.setSelectedId(1, juce::dontSendNotification);  // Set the ID without triggering notification
    updatePresetDropDown(false);  // Initialize the preset dropdown without loading a preset
    
    // Initialize UI with current parameter values
    auto* modelParam = processor.getValueTreeState().getParameter("MODEL");
    if (modelParam) {
        int modelValue = (int)modelParam->convertFrom0to1(modelParam->getValue());
        
        // Find which model name corresponds to this model value
        std::string modelName;
        for (const auto& entry : synthIdMap) {
            if (entry.second == modelValue) {
                modelName = entry.first;
                break;
            }
        }
        
        if (!modelName.empty()) {
            // Find which company this model belongs to
            std::string companyName;
            for (const auto& comp : companyToSynths) {
                auto it = std::find(comp.second.begin(), comp.second.end(), modelName);
                if (it != comp.second.end()) {
                    companyName = comp.first;
                    break;
                }
            }
            
            if (!companyName.empty()) {
                // Select company in the dropdown (triggers updateModelList)
                for (int i = 1; i <= companyBox.getNumItems(); ++i) {
                    if (companyBox.getItemText(i-1).toStdString() == companyName) {
                        companyBox.setSelectedId(i, juce::sendNotification);
                        // After model list is updated, select the correct model
                        for (int j = 1; j <= modelBox.getNumItems(); ++j) {
                            if (modelBox.getItemText(j-1).toStdString() == modelName) {
                                modelBox.setSelectedId(modelBox.getItemId(j-1), juce::dontSendNotification);
                                break;
                            }
                        }
                        break;
                    }
                }
            }
        }
    }

    // --- Delay / Reverb (add Time, FB, Sync controls)-------------------------
    delayToggle.setButtonText("Delay");
    addAndMakeVisible(delayToggle);
    delayToggleAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(vts,"DELAY_ON",delayToggle);

    // ===== NEW: show and hook up the Sync toggle =====
    delaySyncToggle.setButtonText("Sync");
    addAndMakeVisible(delaySyncToggle);
    delaySyncAttachment = std::make_unique<
        juce::AudioProcessorValueTreeState::ButtonAttachment>(vts, "DELAY_SYNC", delaySyncToggle);
    // =================================================

    delayMixSlider.setSliderStyle(juce::Slider::RotaryVerticalDrag);
    delayMixSlider.setTextBoxStyle(juce::Slider::TextBoxBelow,false,50,20);
    addAndMakeVisible(delayMixSlider);
    delayMixLabel.setText("D-Mix", juce::dontSendNotification);
    delayMixLabel.attachToComponent(&delayMixSlider,false);
    delayMixLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(delayMixLabel);
    delayMixAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts,"DELAY_MIX",delayMixSlider);

    delayTimeSlider.setSliderStyle(juce::Slider::RotaryVerticalDrag);
    delayTimeSlider.setTextBoxStyle(juce::Slider::TextBoxBelow,false,50,20);
    addAndMakeVisible(delayTimeSlider);
    delayTimeLabel.setText("Time", juce::dontSendNotification);
    delayTimeLabel.attachToComponent(&delayTimeSlider,false);
    delayTimeLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(delayTimeLabel);
    delayTimeAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts,"DELAY_TIME",delayTimeSlider);

    delayFeedbackSlider.setSliderStyle(juce::Slider::RotaryVerticalDrag);
    delayFeedbackSlider.setTextBoxStyle(juce::Slider::TextBoxBelow,false,50,20);
    addAndMakeVisible(delayFeedbackSlider);
    delayFbLabel.setText("FB", juce::dontSendNotification);
    delayFbLabel.attachToComponent(&delayFeedbackSlider,false);
    delayFbLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(delayFbLabel);
    delayFbAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts,"DELAY_FB",delayFeedbackSlider);

    reverbToggle.setButtonText("Reverb");
    addAndMakeVisible(reverbToggle);
    reverbToggleAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(vts,"REVERB_ON",reverbToggle);

    reverbMixSlider.setSliderStyle(juce::Slider::RotaryVerticalDrag);
    reverbMixSlider.setTextBoxStyle(juce::Slider::TextBoxBelow,false,50,20);
    addAndMakeVisible(reverbMixSlider);
    reverbMixLabel.setText("R-Mix", juce::dontSendNotification);
    reverbMixLabel.attachToComponent(&reverbMixSlider,false);
    reverbMixLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(reverbMixLabel);
    reverbMixAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts,"REVERB_MIX",reverbMixSlider);

    // NEW – Size slider
    reverbSizeSlider.setSliderStyle(juce::Slider::RotaryVerticalDrag);
    reverbSizeSlider.setTextBoxStyle(juce::Slider::TextBoxBelow,false,50,20);
    addAndMakeVisible(reverbSizeSlider);
    reverbSizeLabel.setText("R-Size", juce::dontSendNotification);
    reverbSizeLabel.attachToComponent(&reverbSizeSlider,false);
    reverbSizeLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(reverbSizeLabel);
    reverbSizeAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts,"REVERB_SIZE",reverbSizeSlider);

    // ---------- NEW : Reverb Type selector -----------------------------------
    reverbTypeBox.addItemList({ "Classic","Hall","Plate","Shimmer",
                               "Spring","Room","Cathedral","Gated" },1);
    addAndMakeVisible(reverbTypeBox);
    reverbTypeLabel.setText("R-Type", juce::dontSendNotification);
    reverbTypeLabel.attachToComponent(&reverbTypeBox,false);
    reverbTypeLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(reverbTypeLabel);
    reverbTypeAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(vts,
                                                                                                    "REVERB_TYPE",
                                                                                                    reverbTypeBox);

    // After creating all the sliders but before styling
    
    // Set up larger slider sizes
    const auto setupRotarySlider = [](juce::Slider& slider)
    {
        slider.setSliderStyle(juce::Slider::SliderStyle::RotaryVerticalDrag);
        slider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 60, 20);
        slider.setSize(80, 80); // Make the slider larger
    };
    
    // Apply to all rotary sliders
    for (auto* slider : {&attackSlider, &decaySlider, &sustainSlider, &releaseSlider,
                        &cutoffSlider, &resonanceSlider, 
                        &osc1VolSlider, &osc2VolSlider,
                        &osc2DetuneSlider, &osc1FineSlider, &osc2FineSlider, // NEW: Added tuning sliders
                        &lfoRateSlider, &lfoDepthSlider,
                        &delayMixSlider, &reverbMixSlider, &reverbSizeSlider,
                        &delayTimeSlider, &delayFeedbackSlider,
                        &noiseMixSlider,&driveAmtSlider})
    {
        setupRotarySlider(*slider);
    }
    
    // Make the horizontal slider larger too
    pulseWidthSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 70, 20);
    
    // Modern UI color scheme with section-specific colors
    const juce::Colour bgColor = juce::Colour(12, 12, 18);            // Very dark base
    const juce::Colour oscAccent = juce::Colour(65, 105, 225);        // Royal blue
    const juce::Colour filterAccent = juce::Colour(147, 112, 219);    // Medium purple
    const juce::Colour modAccent = juce::Colour(255, 170, 50);        // Warm amber/gold
    const juce::Colour adsrAccent = juce::Colour(0, 200, 100);         // Vibrant Green (NEW)
    const juce::Colour fxAccent = juce::Colour(64, 224, 208);         // Turquoise
    const juce::Colour textColor = juce::Colour(240, 240, 245);       // Slightly blue-tinted white
    const juce::Colour controlBgColor = juce::Colour(28, 30, 38);     // Slightly lighter than bg

    getLookAndFeel().setColour(juce::ResizableWindow::backgroundColourId, bgColor);
    
    // Style labels with a more modern font
    for (auto* lbl: {&attackLabel,&decayLabel,&sustainLabel,&releaseLabel,&cutoffLabel,&resonanceLabel,
                    &waveformLabel,&pulseWidthLabel,&modelLabel,&osc1VolLabel,&osc2VolLabel,&waveform2Label,
                    &osc2DetuneLabel, &osc1FineLabel, &osc2FineLabel, // NEW: Added tuning labels
                    &lfoRateLabel,&lfoDepthLabel,&delayMixLabel,&delayTimeLabel,&delayFbLabel,
                    &reverbMixLabel, &reverbTypeLabel, &reverbSizeLabel,
                    &noiseMixLabel,&driveAmtLabel,&companyLabel,
                    &presetCategoryLabel,&presetLabel,&consoleModelLabel}) {
        lbl->setColour(juce::Label::textColourId, textColor);
        lbl->setFont(juce::Font(16.0f).withStyle(juce::Font::bold));
    }
    
    // Style oscillator section controls
    for (auto* cb: {&companyBox, &modelBox, &waveformBox, &waveform2Box}) {
        cb->setColour(juce::ComboBox::backgroundColourId, controlBgColor);
        cb->setColour(juce::ComboBox::textColourId, textColor);
        cb->setColour(juce::ComboBox::arrowColourId, oscAccent);
        cb->setColour(juce::ComboBox::outlineColourId, controlBgColor.darker(0.2f));
        cb->setColour(juce::ComboBox::buttonColourId, controlBgColor.darker(0.1f));
        cb->setColour(juce::ComboBox::focusedOutlineColourId, oscAccent.withAlpha(0.5f));
    }
    
    // Style filter section controls
    for (auto* slider: {&cutoffSlider, &resonanceSlider}) {
        slider->setColour(juce::Slider::thumbColourId, filterAccent);
        slider->setColour(juce::Slider::trackColourId, controlBgColor);
        slider->setColour(juce::Slider::rotarySliderFillColourId, filterAccent.withAlpha(0.6f));
        slider->setColour(juce::Slider::rotarySliderOutlineColourId, controlBgColor);
        slider->setColour(juce::Slider::textBoxTextColourId, textColor);
        slider->setColour(juce::Slider::textBoxOutlineColourId, controlBgColor);
        slider->setColour(juce::Slider::textBoxBackgroundColourId, controlBgColor.darker(0.2f));
    }

    // Style modulation section controls
    for (auto* slider: {&lfoRateSlider, &lfoDepthSlider, &noiseMixSlider, &driveAmtSlider}) {
        slider->setColour(juce::Slider::thumbColourId, modAccent);
        slider->setColour(juce::Slider::trackColourId, controlBgColor);
        slider->setColour(juce::Slider::rotarySliderFillColourId, modAccent.withAlpha(0.6f));
        slider->setColour(juce::Slider::rotarySliderOutlineColourId, controlBgColor);
        slider->setColour(juce::Slider::textBoxTextColourId, textColor);
        slider->setColour(juce::Slider::textBoxOutlineColourId, controlBgColor);
        slider->setColour(juce::Slider::textBoxBackgroundColourId, controlBgColor.darker(0.2f));
    }
    
    // ADSR controls with distinct green color
    for (auto* slider : {&attackSlider, &decaySlider, &sustainSlider, &releaseSlider}) {
        slider->setColour(juce::Slider::thumbColourId, adsrAccent);
        slider->setColour(juce::Slider::trackColourId, controlBgColor);
        slider->setColour(juce::Slider::rotarySliderFillColourId, adsrAccent.withAlpha(0.6f));
        slider->setColour(juce::Slider::rotarySliderOutlineColourId, controlBgColor);
        slider->setColour(juce::Slider::textBoxTextColourId, textColor);
        slider->setColour(juce::Slider::textBoxOutlineColourId, controlBgColor);
        slider->setColour(juce::Slider::textBoxBackgroundColourId, controlBgColor.darker(0.2f));
    }

    // Style FX section controls
    for (auto* slider: {&delayMixSlider, &reverbMixSlider, &delayTimeSlider, &delayFeedbackSlider, &reverbSizeSlider}) {
        slider->setColour(juce::Slider::thumbColourId, fxAccent);
        slider->setColour(juce::Slider::trackColourId, controlBgColor);
        slider->setColour(juce::Slider::rotarySliderFillColourId, fxAccent.withAlpha(0.6f));
        slider->setColour(juce::Slider::rotarySliderOutlineColourId, controlBgColor);
        slider->setColour(juce::Slider::textBoxTextColourId, textColor);
        slider->setColour(juce::Slider::textBoxOutlineColourId, controlBgColor);
        slider->setColour(juce::Slider::textBoxBackgroundColourId, controlBgColor.darker(0.2f));
    }

    // Style toggle buttons based on their section
    lfoToggle.setLookAndFeel(&modernToggleLookAndFeel);
    noiseToggle.setLookAndFeel(&modernToggleLookAndFeel);
    driveToggle.setLookAndFeel(&modernToggleLookAndFeel);
    
    delayToggle.setLookAndFeel(&modernToggleLookAndFeel);
    reverbToggle.setLookAndFeel(&modernToggleLookAndFeel);
    delaySyncToggle.setLookAndFeel(&modernToggleLookAndFeel);
    consoleToggle.setLookAndFeel(&modernToggleLookAndFeel);
    oscSyncToggle.setLookAndFeel(&modernToggleLookAndFeel);      // NEW

    lfoToggle.setColour(juce::ToggleButton::textColourId, textColor);
    lfoToggle.setColour(juce::ToggleButton::tickColourId, modAccent);
    noiseToggle.setColour(juce::ToggleButton::textColourId, textColor);
    noiseToggle.setColour(juce::ToggleButton::tickColourId, modAccent);
    driveToggle.setColour(juce::ToggleButton::textColourId, textColor);
    driveToggle.setColour(juce::ToggleButton::tickColourId, modAccent);
    
    delayToggle.setColour(juce::ToggleButton::textColourId, textColor);
    delayToggle.setColour(juce::ToggleButton::tickColourId, fxAccent);
    reverbToggle.setColour(juce::ToggleButton::textColourId, textColor);
    reverbToggle.setColour(juce::ToggleButton::tickColourId, fxAccent);
    delaySyncToggle.setColour(juce::ToggleButton::textColourId, textColor);
    delaySyncToggle.setColour(juce::ToggleButton::tickColourId, fxAccent);
    consoleToggle.setColour(juce::ToggleButton::textColourId, textColor);
    consoleToggle.setColour(juce::ToggleButton::tickColourId, fxAccent);
    oscSyncToggle.setColour(juce::ToggleButton::textColourId, textColor);   // NEW
    oscSyncToggle.setColour(juce::ToggleButton::tickColourId, oscAccent);   // NEW

    // Style FX-specific combo boxes
    for (auto* cb: {&reverbTypeBox, &consoleModelBox}) {
        cb->setColour(juce::ComboBox::backgroundColourId, controlBgColor);
        cb->setColour(juce::ComboBox::textColourId, textColor);
        cb->setColour(juce::ComboBox::arrowColourId, fxAccent);
        cb->setColour(juce::ComboBox::outlineColourId, controlBgColor.darker(0.2f));
        cb->setColour(juce::ComboBox::buttonColourId, controlBgColor.darker(0.1f));
        cb->setColour(juce::ComboBox::focusedOutlineColourId, fxAccent.withAlpha(0.5f));
    }

    // Style preset section controls with a mix of colors
    for (auto* cb: {&presetCategoryBox, &presetBox}) {
        cb->setColour(juce::ComboBox::backgroundColourId, controlBgColor);
        cb->setColour(juce::ComboBox::textColourId, textColor);
        cb->setColour(juce::ComboBox::arrowColourId, oscAccent);
        cb->setColour(juce::ComboBox::outlineColourId, controlBgColor.darker(0.2f));
        cb->setColour(juce::ComboBox::buttonColourId, controlBgColor.darker(0.1f));
        cb->setColour(juce::ComboBox::focusedOutlineColourId, oscAccent.withAlpha(0.5f));
    }

    // Style navigation buttons with section-specific colors
    const auto setupNavButton = [&](juce::TextButton& button, const juce::Colour& accent) {
        button.setColour(juce::TextButton::buttonColourId, controlBgColor);
        button.setColour(juce::TextButton::buttonOnColourId, controlBgColor.brighter(0.1f));
        button.setColour(juce::TextButton::textColourOffId, accent);
        button.setColour(juce::TextButton::textColourOnId, accent.brighter(0.2f));
    };

    // Preset nav buttons
    for (auto* btn : {&presetCategoryUpButton, &presetCategoryDownButton,
                      &presetUpButton, &presetDownButton}) {
        setupNavButton(*btn, oscAccent);
    }

    // Model nav buttons
    for (auto* btn : {&companyUpButton, &companyDownButton,
                      &modelUpButton, &modelDownButton}) {
        setupNavButton(*btn, filterAccent);
    }

    // Set the window size
    setSize(1200, 850); // Increased height to accommodate all controls
    
    // Make our first selection
    updatePresetDropDown();
}

//==============================================================================
void AllSynthPluginAudioProcessorEditor::updateModelList()
{
    // Filter models by selected company
    auto compName = companyBox.getText().toStdString();
    modelBox.clear(juce::dontSendNotification);
    if (companyToSynths.count(compName) > 0) {
        for (auto& synth : companyToSynths[compName]) {
            auto it = synthIdMap.find(synth);
            if (it != synthIdMap.end())
                modelBox.addItem(synth, it->second + 1);      // make ID ≥ 1
        }
    }
    // Ensure first item selected
    if (modelBox.getNumItems() > 0)
        modelBox.setSelectedId(modelBox.getItemId(0), juce::dontSendNotification);
}

//==============================================================================
// NEW: update preset dropdown based on category
//==============================================================================
void AllSynthPluginAudioProcessorEditor::updatePresetDropDown(bool shouldLoadPreset)
{
    // Static flag to track first initialization and avoid loading presets
    // during automatic UI creation when switching to the plugin in Reaper
    static bool isFirstCall = true;
    
    // NEW: Persistent flag to detect host environments like Reaper where we need to skip preset loading
    // This helps prevent the issue where presets get reset when the plugin window is closed and reopened
    static bool shouldSkipHostReset = false;
    
    auto cat = presetCategoryBox.getText().toStdString();
    presetBox.clear(juce::dontSendNotification);

    if (categoryToPresetIndices.count(cat))
        for (int idx : categoryToPresetIndices[cat])
            presetBox.addItem(processor.getPresets()[idx].name, idx + 1);

    if (presetBox.getNumItems() > 0) {
        // First select the item without notification
        int firstItemId = presetBox.getItemId(0);
        presetBox.setSelectedId(firstItemId, juce::dontSendNotification);
        
        // Only load the preset if explicitly requested AND not during first UI initialization
        // NEW: Also don't load if we've detected that we're in a host environment with reset issues
        if (shouldLoadPreset && !isFirstCall && !shouldSkipHostReset) {
            // Then manually load the preset
            int presetIndex = firstItemId - 1;  // ItemId = presetIndex+1
            processor.loadPreset(presetIndex);
            
            // Update company and model dropdowns to match the MODEL parameter
            auto* modelParam = processor.getValueTreeState().getParameter("MODEL");
            if (modelParam) {
                int modelValue = (int)modelParam->convertFrom0to1(modelParam->getValue());
                
                // Find which model name corresponds to this model value
                std::string modelName;
                for (const auto& entry : synthIdMap) {
                    if (entry.second == modelValue) {
                        modelName = entry.first;
                        break;
                    }
                }
                
                if (!modelName.empty()) {
                    // Find which company this model belongs to
                    std::string companyName;
                    for (const auto& comp : companyToSynths) {
                        auto it = std::find(comp.second.begin(), comp.second.end(), modelName);
                        if (it != comp.second.end()) {
                            companyName = comp.first;
                            break;
                        }
                    }
                    
                    if (!companyName.empty()) {
                        // Select company in the dropdown (triggers updateModelList)
                        for (int i = 1; i <= companyBox.getNumItems(); ++i) {
                            if (companyBox.getItemText(i-1).toStdString() == companyName) {
                                companyBox.setSelectedId(i, juce::sendNotification);
                                // After model list is updated, select the correct model
                                for (int j = 1; j <= modelBox.getNumItems(); ++j) {
                                    if (modelBox.getItemText(j-1).toStdString() == modelName) {
                                        modelBox.setSelectedId(modelBox.getItemId(j-1), juce::dontSendNotification);
                                        break;
                                    }
                                }
                                break;
                            }
                        }
                    }
                }
            }
        }
    }
    
    // If this is the first call during initialization and we loaded the preset dropdown successfully,
    // set the flag to prevent automatic preset loading on subsequent category changes
    if (isFirstCall && presetBox.getNumItems() > 0) {
        shouldSkipHostReset = true;
    }
    
    // After the first call, reset the isFirstCall flag so future explicit user interactions
    // can be properly detected
    isFirstCall = false;
}

// Destructor is defaulted in the header

void AllSynthPluginAudioProcessorEditor::paint(juce::Graphics& g)
{
    // Deep, dark background with cool undertone
    g.fillAll(juce::Colour(8, 12, 10));  // Added slight green tint to base

    // Define section colors - cool, dark palette with green tints
    const juce::Colour oscSection     = juce::Colour(18, 88, 78);    // More green-teal
    const juce::Colour filterSection  = juce::Colour(28, 52, 44);    // Deep green-blue
    const juce::Colour modulateSection = juce::Colour(42, 48, 54);   // Slate with green
    const juce::Colour fxSection      = juce::Colour(28, 74, 58);    // Rich green-teal
    
    // --- NEW: Define more vibrant colors for section label panels ---
    const juce::Colour oscLabelAccent     = juce::Colour(30, 190, 170);   // Bright Teal
    const juce::Colour filterLabelAccent  = juce::Colour(70, 140, 190);   // Brighter Blue-Green
    const juce::Colour modLabelAccent     = juce::Colour(255, 180, 60);   // Vibrant Amber (Matches Mod controls)
    const juce::Colour fxLabelAccent      = juce::Colour(80, 230, 210);   // Bright Turquoise (Matches FX controls)
    // -----------------------------------------------------------------

    float sectionWidth = getWidth() / 4.0f;
    float height = (float)getHeight();

    // Create audio-themed background textures
    juce::Image audioTextures(juce::Image::ARGB, getWidth(), getHeight(), true);
    juce::Graphics ag(audioTextures);

    // Draw grid pattern with VU meter style markers
    ag.setColour(juce::Colours::white.withAlpha(0.08f));  // More visible grid (was 0.05f)
    const float gridSize = 40.0f;
    const float markerSize = 3.0f;
    
    for (float x = gridSize; x < getWidth(); x += gridSize) {
        for (float y = gridSize; y < height; y += gridSize) {
            if ((int)(x / gridSize) % 3 == 0) {
                ag.drawLine(x - 4, y, x + 4, y, 1.5f);  // Thicker lines
            } else {
                ag.fillEllipse(x - markerSize/2, y - markerSize/2, 
                             markerSize, markerSize);
            }
        }
    }

    // Draw frequency markers (vertical lines with Hz labels)
    ag.setColour(juce::Colours::white.withAlpha(0.08f));  // More visible markers
    const float freqX[] = {0.2f, 0.4f, 0.6f, 0.8f};
    const char* freqLabels[] = {"20Hz", "1kHz", "10kHz", "20kHz"};
    for (int i = 0; i < 4; ++i) {
        float x = getWidth() * freqX[i];
        ag.drawVerticalLine((int)x, 0.0f, height);
        ag.setFont(14.0f);
        ag.drawText(freqLabels[i], (int)x - 20, height - 25, 40, 20, 
                   juce::Justification::centred, false);
    }

    // Draw waveform patterns in each section
    ag.setColour(juce::Colours::white.withAlpha(0.12f));  // More visible waveforms (was 0.08f)
    
    // Oscillator section - Saw and Sine waves
    float oscWidth = sectionWidth * 0.8f;
    float waveHeight = 40.0f;
    float waveY = height * 0.2f;
    
    // Draw saw wave
    juce::Path sawWave;
    sawWave.startNewSubPath(20, waveY);
    for (float x = 20; x < oscWidth; x += 50.0f) {
        sawWave.lineTo(x, waveY - waveHeight);
        sawWave.lineTo(x, waveY + waveHeight);
    }
    ag.strokePath(sawWave, juce::PathStrokeType(2.0f));  // Thicker line

    // Draw sine wave
    juce::Path sineWave;
    sineWave.startNewSubPath(20, waveY + 100.0f);
    for (float x = 20; x < oscWidth; x += 2.0f) {
        sineWave.lineTo(x, waveY + 100.0f + std::sin(x * 0.08f) * waveHeight);
    }
    ag.strokePath(sineWave, juce::PathStrokeType(2.0f));  // Thicker line

    // Filter section - Filter curve
    ag.setColour(juce::Colours::white.withAlpha(0.15f));  // More visible filter curve
    juce::Path filterCurve;
    float filterX = sectionWidth + 20;
    float filterWidth = sectionWidth * 0.8f;
    filterCurve.startNewSubPath(filterX, height * 0.7f);
    for (float x = 0; x <= filterWidth; x += 2.0f) {
        float response = 1.0f / (1.0f + std::pow((x / filterWidth) * 3.0f, 4));
        filterCurve.lineTo(filterX + x, height * 0.7f - response * height * 0.4f);
    }
    ag.strokePath(filterCurve, juce::PathStrokeType(2.5f));  // Thicker line

    // Modulation section - LFO pattern
    ag.setColour(juce::Colours::white.withAlpha(0.12f));  // More visible LFO
    float modX = sectionWidth * 2 + 20;
    float modWidth = sectionWidth * 0.8f;
    juce::Path lfoWave;
    lfoWave.startNewSubPath(modX, height * 0.4f);
    for (float x = 0; x <= modWidth; x += 2.0f) {
        float y = height * 0.4f + std::sin(x * 0.03f) * 50.0f;
        lfoWave.lineTo(modX + x, y);
    }
    ag.strokePath(lfoWave, juce::PathStrokeType(2.5f));  // Thicker line

    // FX section - Delay/Reverb visualization
    float fxX = sectionWidth * 3 + 20;
    float fxWidth = sectionWidth * 0.8f;
    for (int i = 0; i < 6; ++i) {
        float alpha = 0.15f / (i + 1);  // More visible FX boxes (was 0.12f)
        ag.setColour(juce::Colours::white.withAlpha(alpha));
        float offset = i * 20.0f;
        ag.drawRect(fxX + offset, height * 0.3f + offset, 
                   fxWidth - offset * 2, height * 0.3f, 2.5f);  // Thicker lines
    }

    // Draw main sections with dark gradients
    for (int i = 0; i < 4; ++i) {
        juce::Colour baseColor;
        switch (i) {
            // --- NEW: Use Label Accent colors for background hue ---
            case 0: baseColor = oscLabelAccent; break;      // Was oscSection
            case 1: baseColor = filterLabelAccent; break;   // Was filterSection
            case 2: baseColor = modLabelAccent; break;      // Was modulateSection
            case 3: baseColor = fxLabelAccent; break;       // Was fxSection
            // -----------------------------------------------------
        }

        // Use the accent hue but keep the original low alpha values for subtlety
        // --- NEW: Use much lower alpha values for darker backgrounds ---
        // --- NEWER: Even darker alpha values --- 
        juce::ColourGradient gradient(
            baseColor.withAlpha(0.06f),  // Was 0.10f
            i * sectionWidth, 0.0f,
            baseColor.withAlpha(0.03f),  // Was 0.05f
            i * sectionWidth, height,
            false
        );
        
        gradient.addColour(0.3, baseColor.withAlpha(0.05f)); // Was 0.08f
        gradient.addColour(0.7, baseColor.withAlpha(0.04f)); // Was 0.07f
        // -------------------------------------------------------------
        
        g.setGradientFill(gradient);
        g.fillRect(i * sectionWidth, 0.0f, sectionWidth, height);

        // Also update the top glow to use the accent color hue and darker alpha
        juce::ColourGradient topGlow(
            baseColor.withAlpha(0.06f),  // Was 0.10f
            i * sectionWidth, 0.0f,
            baseColor.withAlpha(0.0f),
            i * sectionWidth, 100.0f,
            false
        );
        g.setGradientFill(topGlow);
        g.fillRect(i * sectionWidth, 0.0f, sectionWidth, 100.0f);
    }

    // Apply all textures
    g.setOpacity(1.0f);
    g.drawImageAt(audioTextures, 0, 0);

    // Add section dividers with dark panel style
    for (int i = 1; i < 4; ++i) {
        float x = sectionWidth * i;
        g.setColour(juce::Colours::white.withAlpha(0.12f));  // More visible dividers (was 0.08f)
        g.drawVerticalLine((int)x - 1, 0.0f, height);
        g.setColour(juce::Colours::black.withAlpha(0.4f));  // More visible shadow (was 0.3f)
        g.drawVerticalLine((int)x, 0.0f, height);
    }

    // Add subtle blue-green glow to the top
    juce::ColourGradient finalGlow(  // Renamed from topGlow to avoid conflict
        juce::Colour(18, 88, 78).withAlpha(0.15f),  // More green tint and more visible (was 0.1f)
        0.0f, 0.0f,
        juce::Colour(18, 88, 78).withAlpha(0.0f),
        0.0f, 100.0f,
        false
    );
    g.setGradientFill(finalGlow);
    g.fillRect(0.0f, 0.0f, (float)getWidth(), 100.0f);

    // Add section labels with clean text
    g.setFont(20.0f);
    g.setColour(juce::Colours::white.withAlpha(0.7f));
    
    // Section labels very close to the bottom with minimal size
    const int labelY = height - 30;  // Move labels even closer to bottom (was -25)
    const float labelWidth = 60.0f;  // Make labels even narrower (was 80)
    const float labelHeight = 16.0f; // Make labels shorter (was 22)
    
    // Draw section labels with futuristic style
    for (int i = 0; i < 4; ++i) {
        float x = sectionWidth * (i + 0.5f) - labelWidth * 0.5f;
        
        // Draw background panel with brighter colors and angular design
        juce::Colour panelColor;
        switch (i) {
            // --- Use NEW vibrant accent colors ---
            case 0: panelColor = oscLabelAccent.withAlpha(0.85f); break;
            case 1: panelColor = filterLabelAccent.withAlpha(0.85f); break;
            case 2: panelColor = modLabelAccent.withAlpha(0.85f); break;
            case 3: panelColor = fxLabelAccent.withAlpha(0.85f); break;
            // -------------------------------------
        }
        
        // Create futuristic path for the label background
        juce::Path labelPath;
        labelPath.startNewSubPath(x + 3, labelY);
        labelPath.lineTo(x + labelWidth - 3, labelY);
        labelPath.lineTo(x + labelWidth, labelY + 3);
        labelPath.lineTo(x + labelWidth, labelY + labelHeight - 3);
        labelPath.lineTo(x + labelWidth - 3, labelY + labelHeight);
        labelPath.lineTo(x + 3, labelY + labelHeight);
        labelPath.lineTo(x, labelY + labelHeight - 3);
        labelPath.lineTo(x, labelY + 3);
        labelPath.closeSubPath();
        
        // Draw main panel
        g.setColour(panelColor);
        g.fillPath(labelPath);
        
        // Add subtle outer glow (using the brighter panel color)
        g.setColour(panelColor.brighter(0.3f).withAlpha(0.4f)); // Slightly brighter glow
        g.strokePath(labelPath, juce::PathStrokeType(1.0f)); // Slightly thicker glow
        
        // Add tech lines on the sides (shorter now)
        g.setColour(juce::Colours::white.withAlpha(0.4f)); // Slightly brighter tech lines
        g.drawLine(x - 3, labelY + labelHeight * 0.5f, x, labelY + labelHeight * 0.5f, 0.8f);
        g.drawLine(x + labelWidth, labelY + labelHeight * 0.5f, x + labelWidth + 3, labelY + labelHeight * 0.5f, 0.8f);
        
        // Draw label text with smaller tech font
        g.setColour(juce::Colours::white.withAlpha(0.95f));
        g.setFont(12.0f);  // Smaller font size (was 16)
        const char* label;
        switch (i) {
            case 0: label = "OSC"; break;
            case 1: label = "FILTER"; break;
            case 2: label = "MOD"; break;
            case 3: label = "FX"; break;
        }
        g.drawText(label, x, labelY, labelWidth, labelHeight, juce::Justification::centred);
    }

    // Add minimal bottom shadow
    juce::ColourGradient bottomShadow(
        juce::Colours::black.withAlpha(0.0f), 0.0f, height - 25.0f,
        juce::Colours::black.withAlpha(0.3f), 0.0f, height,
        false
    );
    g.setGradientFill(bottomShadow);
    g.fillRect(0.0f, height - 50.0f, (float)getWidth(), 50.0f);

    // Add dark vignette effect
    juce::ColourGradient vignette(
        juce::Colours::black.withAlpha(0.4f), getWidth() * 0.5f, height * 0.5f,
        juce::Colours::black.withAlpha(0.0f), 0.0f, 0.0f,
        true
    );
    g.setGradientFill(vignette);
    g.fillRect(0.0f, 0.0f, (float)getWidth(), height);

    // Add subtle blue glow to the top
    juce::ColourGradient topGlow(
        juce::Colour(18, 78, 98).withAlpha(0.1f), 0.0f, 0.0f,
        juce::Colour(18, 78, 98).withAlpha(0.0f), 0.0f, 100.0f,
        false
    );
    g.setGradientFill(topGlow);
    g.fillRect(0.0f, 0.0f, (float)getWidth(), 100.0f);
}

void AllSynthPluginAudioProcessorEditor::resized()
{
    auto bounds = getLocalBounds().reduced(30); // Increased margin from 25 to 30

    // Define button width and gap
    const int buttonWidth = 25;
    const int buttonGap = 5;

    // ---- Top row for presets ----
    auto presetRow = bounds.removeFromTop(70);
    auto presetHalfWidth = presetRow.getWidth() / 2;

    // Category Area (Left)
    auto categoryArea = presetRow.removeFromLeft(presetHalfWidth).reduced(20, 15);
    presetCategoryUpButton.setBounds(categoryArea.removeFromRight(buttonWidth));
    categoryArea.removeFromRight(buttonGap); // Gap
    presetCategoryDownButton.setBounds(categoryArea.removeFromRight(buttonWidth));
    categoryArea.removeFromRight(buttonGap); // Gap
    presetCategoryBox.setBounds(categoryArea);
    presetCategoryLabel.setTopLeftPosition(presetCategoryBox.getX(), presetCategoryBox.getY() - 25);

    // Preset Area (Right)
    auto presetArea = presetRow.reduced(20, 15);
    presetUpButton.setBounds(presetArea.removeFromRight(buttonWidth));
    presetArea.removeFromRight(buttonGap); // Gap
    presetDownButton.setBounds(presetArea.removeFromRight(buttonWidth));
    presetArea.removeFromRight(buttonGap); // Gap
    presetBox.setBounds(presetArea);
    presetLabel.setTopLeftPosition(presetBox.getX(), presetBox.getY() - 25);

    // Keep 4 columns, but they will be wider now
    const int columnWidth = bounds.getWidth() / 4;
    auto oscModelArea  = bounds.removeFromLeft(columnWidth);
    auto filterEnvArea = bounds.removeFromLeft(columnWidth); // Filter + Env
    auto lfoNoiseArea  = bounds.removeFromLeft(columnWidth); // LFO + Noise/Drive
    auto fxArea        = bounds;                             // Remaining width for FX

    // --- Column 1: Oscillators & Model ---
    // Allocate more space for oscillator controls, less for model selection
    auto oscSectionHeight = oscModelArea.getHeight() * 0.75f; // Increased from 0.65f
    auto modelSectionHeight = oscModelArea.getHeight() * 0.25f;// Decreased from 0.35f
    auto oscArea   = oscModelArea.removeFromTop(oscSectionHeight);
    auto modelArea = oscModelArea;

    // Give rows slightly more space - Now 6 rows with better spacing
    auto oscRowHeight = oscArea.getHeight() / 6;
    
    // Make dropdown controls narrower by adding more horizontal padding
    auto oscPaddingX = 35; // Increase horizontal padding significantly for dropdown menus
    auto oscPaddingY = 8;  // Slightly reduced vertical padding for better spacing
    
    // Reduce width of dropdown menus by 70% of their container
    auto dropdownWidth = oscArea.getWidth() * 0.7f;
    auto dropdownX = (oscArea.getWidth() - dropdownWidth) / 2;
    
    // Set bounds for wave dropdown menus - centered and narrower
    auto waveform1Area = oscArea.removeFromTop(oscRowHeight);
    float dropdownHeight = waveform1Area.getHeight() * 0.5f; // Made dropdowns shorter (was 0.6f)
    waveformBox.setBounds(waveform1Area.withSizeKeepingCentre(dropdownWidth, dropdownHeight));
    waveformLabel.setTopLeftPosition(waveformBox.getX(), waveformBox.getY() - 25);
    
    auto waveform2Area = oscArea.removeFromTop(oscRowHeight);
    waveform2Box.setBounds(waveform2Area.withSizeKeepingCentre(dropdownWidth, dropdownHeight));
    waveform2Label.setTopLeftPosition(waveform2Box.getX(), waveform2Box.getY() - 25);

    // Place volume sliders side by side
    auto volumeSliderArea = oscArea.removeFromTop(oscRowHeight);
    auto volSliderHalfWidth = volumeSliderArea.getWidth() / 2;
    osc1VolSlider.setBounds(volumeSliderArea.removeFromLeft(volSliderHalfWidth).reduced(5, oscPaddingY));
    osc2VolSlider.setBounds(volumeSliderArea.reduced(5, oscPaddingY));
    osc1VolLabel.setTopLeftPosition(osc1VolSlider.getX(), osc1VolSlider.getY() - 20);
    osc2VolLabel.setTopLeftPosition(osc2VolSlider.getX(), osc2VolSlider.getY() - 20);

    // Detune right under Vol 2 (right side only)
    auto detuneArea = oscArea.removeFromTop(oscRowHeight);
    auto detuneHalfArea = detuneArea.removeFromRight(volSliderHalfWidth);
    osc2DetuneSlider.setBounds(detuneHalfArea.reduced(5, oscPaddingY));
    // NEW : sync toggle takes the remaining (left) half
    oscSyncToggle.setBounds(detuneArea.reduced(15, oscPaddingY));

    // Fine tune controls side by side
    auto fineArea = oscArea.removeFromTop(oscRowHeight);
    osc1FineSlider.setBounds(fineArea.removeFromLeft(volSliderHalfWidth).reduced(5, oscPaddingY));
    osc2FineSlider.setBounds(fineArea.reduced(5, oscPaddingY));
    
    // Pulse width in remaining space
    auto pwArea = oscArea.removeFromTop(oscRowHeight);
    pulseWidthSlider.setBounds(pwArea.reduced(oscPaddingX - 20, oscPaddingY));
    pulseWidthLabel.setTopLeftPosition(pulseWidthSlider.getX(), pulseWidthSlider.getY() - 20);

    // Synth model dropdowns - smaller height
    auto modelRowHeight = modelArea.getHeight() / 2;
    auto modelDropdownWidthRatio = 0.7f;
    auto totalModelControlWidth = modelArea.getWidth() * modelDropdownWidthRatio;
    auto modelDropdownWidth = totalModelControlWidth - (2 * buttonWidth + 2 * buttonGap);
    
    float modelDropdownHeight = modelRowHeight * 0.4f; // Made model dropdowns shorter (was 0.6f)

    auto companyAreaFull = modelArea.removeFromTop(modelRowHeight);
    auto companyControlBounds = companyAreaFull.withSizeKeepingCentre(totalModelControlWidth, modelDropdownHeight);
    companyBox.setBounds(companyControlBounds.removeFromLeft(modelDropdownWidth));
    companyControlBounds.removeFromLeft(buttonGap);
    companyUpButton.setBounds(companyControlBounds.removeFromLeft(buttonWidth));
    companyControlBounds.removeFromLeft(buttonGap);
    companyDownButton.setBounds(companyControlBounds);
    companyLabel.setTopLeftPosition(companyBox.getX(), companyBox.getY() - 20); // Reduced spacing (was -25)

    auto modelAreaFull = modelArea;
    auto modelControlBounds = modelAreaFull.withSizeKeepingCentre(totalModelControlWidth, modelDropdownHeight);
    modelBox.setBounds(modelControlBounds.removeFromLeft(modelDropdownWidth));
    modelControlBounds.removeFromLeft(buttonGap);
    modelUpButton.setBounds(modelControlBounds.removeFromLeft(buttonWidth));
    modelControlBounds.removeFromLeft(buttonGap);
    modelDownButton.setBounds(modelControlBounds);
    modelLabel.setTopLeftPosition(modelBox.getX(), modelBox.getY() - 20); // Reduced spacing (was -25)

    // --- Column 2: Filter & Amp Envelope ---
    auto filterSectionHeight = filterEnvArea.getHeight() * 0.30f; // Less space for filter
    auto envSectionHeight    = filterEnvArea.getHeight() * 0.70f; // More space for Env

    auto filterArea = filterEnvArea.removeFromTop(filterSectionHeight);
    auto envArea    = filterEnvArea;

    auto filterSliderWidth = filterArea.getWidth() / 2;
    auto filterPadding = 10; // Increase padding
    cutoffSlider   .setBounds(filterArea.removeFromLeft(filterSliderWidth).reduced(filterPadding));
    resonanceSlider.setBounds(filterArea.reduced(filterPadding));

    const int numEnvSliders = 4;
    auto envSliderHeight = envArea.getHeight() / numEnvSliders;
    auto envPadding = 15; // Slightly increased padding
    attackSlider .setBounds(envArea.removeFromTop(envSliderHeight).reduced(envPadding));
    decaySlider  .setBounds(envArea.removeFromTop(envSliderHeight).reduced(envPadding));
    sustainSlider.setBounds(envArea.removeFromTop(envSliderHeight).reduced(envPadding));
    releaseSlider.setBounds(envArea.reduced(envPadding));

    // --- Column 3: LFO & Noise/Drive ---
    auto lfoSectionHeight = lfoNoiseArea.getHeight() * 0.45f; // More space for LFO
    auto noiseDriveSectionHeight = lfoNoiseArea.getHeight() * 0.55f; // More space for Noise/Drive

    auto lfoArea        = lfoNoiseArea.removeFromTop(lfoSectionHeight);
    auto noiseDriveArea = lfoNoiseArea;

    auto lfoRowHeight = lfoArea.getHeight() / 3;
    auto lfoPaddingX = 30; // More horizontal padding for toggles
    auto lfoPaddingY = 8;
    lfoToggle     .setBounds(lfoArea.removeFromTop(lfoRowHeight).reduced(lfoPaddingX, lfoPaddingY + 5)); // Extra Y padding
    lfoRateSlider .setBounds(lfoArea.removeFromTop(lfoRowHeight).reduced(envPadding)); // Reuse envPadding
    lfoDepthSlider.setBounds(lfoArea.reduced(envPadding));

    auto noiseDriveRowHeight = noiseDriveArea.getHeight() / 4;
    noiseToggle   .setBounds(noiseDriveArea.removeFromTop(noiseDriveRowHeight).reduced(lfoPaddingX, lfoPaddingY));
    noiseMixSlider.setBounds(noiseDriveArea.removeFromTop(noiseDriveRowHeight).reduced(envPadding));
    driveToggle   .setBounds(noiseDriveArea.removeFromTop(noiseDriveRowHeight).reduced(lfoPaddingX, lfoPaddingY));
    driveAmtSlider.setBounds(noiseDriveArea.reduced(envPadding));

    // --- Column 4: FX (Reorganized for better spacing and centering) ---
    auto fxPaddingX = 20; // General horizontal padding within the section
    auto fxSliderPadding = 5;
    auto fxSectionPaddingY = 10;
    auto fxToggleWidth = 100; // Increased from 80 to accommodate longer text
    auto fxBoxWidth = 120;   // Standard width for combo boxes

    // Define the rightward shift amount (two "notches")
    const float rightShift = 20.0f;

    // Calculate the center X of the FX area for easier centering
    float fxCenterX = fxArea.getCentreX();

    // Section heights (approximate distribution)
    float delayToggleHeight = fxArea.getHeight() * 0.12f; // Adjusted heights slightly
    float delaySlidersHeight = fxArea.getHeight() * 0.33f;
    float reverbToggleHeight = fxArea.getHeight() * 0.12f;
    float reverbSlidersHeight = fxArea.getHeight() * 0.28f;
    float consoleHeight = fxArea.getHeight() * 0.15f;

    // Delay Section Toggles (Centered side-by-side with rightward shift)
    auto delayToggleArea = fxArea.removeFromTop(delayToggleHeight).reduced(0, fxSectionPaddingY);
    float totalDelayToggleWidth = fxToggleWidth * 2 + 10; // Two toggles + spacing
    auto delayTogglesBounds = delayToggleArea.withSizeKeepingCentre(totalDelayToggleWidth, delayToggleArea.getHeight());
    delayTogglesBounds.setX(delayTogglesBounds.getX() + rightShift); // Shift right
    delayToggle.setBounds(delayTogglesBounds.removeFromLeft(fxToggleWidth));
    delayTogglesBounds.removeFromLeft(10); // Spacing
    // --- NEW: Restore bounds setting for delaySyncToggle ---
    delaySyncToggle.setBounds(delayTogglesBounds);
    // --------------------------------------------------------

    // Delay Sliders (Already centered, now with rightward shift)
    auto delaySliderArea = fxArea.removeFromTop(delaySlidersHeight).reduced(0, fxSectionPaddingY);
    const float reverbSliderWidthForDelay = delaySliderArea.getWidth() / 3 - 15;
    const float reverbSliderHeightForDelay = delaySliderArea.getHeight() * 0.7f;
    const float delaySliderWidth = reverbSliderWidthForDelay * 0.85f;
    const float delaySliderHeight = reverbSliderHeightForDelay * 0.85f;
    const float totalDelayControlsWidth = 3 * delaySliderWidth + 2 * 20;
    // Adjust margin to account for rightward shift
    const float delayLeftMargin = (delaySliderArea.getWidth() - totalDelayControlsWidth) / 2 + rightShift;
    
    auto delayMixBounds = delaySliderArea.removeFromLeft(delayLeftMargin + delaySliderWidth);
    delayMixSlider.setBounds(delayMixBounds.withWidth(delaySliderWidth).withHeight(delaySliderHeight)
                           .withY(delayMixBounds.getY() + (delayMixBounds.getHeight() - delaySliderHeight) / 2)
                           .withX(delayMixBounds.getRight() - delaySliderWidth));
    delayMixLabel.setTopLeftPosition(delayMixSlider.getX() + (delayMixSlider.getWidth() - delayMixLabel.getWidth()) / 2,
                                   delayMixSlider.getY() - 25);
    delaySliderArea.removeFromLeft(20);
    auto delayTimeBounds = delaySliderArea.removeFromLeft(delaySliderWidth);
    delayTimeSlider.setBounds(delayTimeBounds.withHeight(delaySliderHeight)
                            .withY(delayTimeBounds.getY() + (delayTimeBounds.getHeight() - delaySliderHeight) / 2));
    delayTimeLabel.setTopLeftPosition(delayTimeSlider.getX() + (delayTimeSlider.getWidth() - delayTimeLabel.getWidth()) / 2,
                                    delayTimeSlider.getY() - 25);
    delaySliderArea.removeFromLeft(20);
    auto delayFeedbackBounds = delaySliderArea.removeFromLeft(delaySliderWidth);
    delayFeedbackSlider.setBounds(delayFeedbackBounds.withHeight(delaySliderHeight)
                                .withY(delayFeedbackBounds.getY() + (delayFeedbackBounds.getHeight() - delaySliderHeight) / 2));
    delayFbLabel.setTopLeftPosition(delayFeedbackSlider.getX() + (delayFeedbackSlider.getWidth() - delayFbLabel.getWidth()) / 2,
                                  delayFeedbackSlider.getY() - 25);

    // Reverb Section Toggle & Box (Centered side-by-side with rightward shift)
    auto reverbToggleArea = fxArea.removeFromTop(reverbToggleHeight).reduced(0, fxSectionPaddingY);
    float totalReverbToggleWidth = fxToggleWidth * 2 + 10; // Two toggles + spacing
    auto reverbTogglesBounds = reverbToggleArea.withSizeKeepingCentre(totalReverbToggleWidth, reverbToggleArea.getHeight());
    reverbTogglesBounds.setX(reverbTogglesBounds.getX() + rightShift); // Shift right
    reverbToggle.setBounds(reverbTogglesBounds.removeFromLeft(fxToggleWidth));
    reverbTogglesBounds.removeFromLeft(10); // Spacing
    reverbTypeBox.setBounds(reverbTogglesBounds);
    // Reverb Type Label needs positioning relative to the box now
    reverbTypeLabel.setTopLeftPosition(reverbTypeBox.getX() + (reverbTypeBox.getWidth() - reverbTypeLabel.getWidth()) / 2,
                                       reverbTypeBox.getY() - 25);


    // Reverb Sliders (Center horizontally with rightward shift)
    auto reverbSliderArea = fxArea.removeFromTop(reverbSlidersHeight).reduced(0, fxSectionPaddingY);
    const float reverbSliderWidth = reverbSliderArea.getWidth() / 2 - 15; // Two sliders, 15px extra spacing total
    const float reverbSliderHeight = reverbSliderArea.getHeight() * 0.7f;
    const float totalReverbSliderWidth = 2 * reverbSliderWidth + 10; // 2 sliders + 10px spacing
    // Adjust margin to account for rightward shift
    const float reverbLeftMargin = (reverbSliderArea.getWidth() - totalReverbSliderWidth) / 2 + rightShift;

    auto reverbMixBounds = reverbSliderArea.removeFromLeft(reverbLeftMargin + reverbSliderWidth);
    reverbMixSlider.setBounds(reverbMixBounds.withWidth(reverbSliderWidth).withHeight(reverbSliderHeight)
                             .withY(reverbMixBounds.getY() + (reverbMixBounds.getHeight() - reverbSliderHeight) / 2)
                             .withX(reverbMixBounds.getRight() - reverbSliderWidth));
    reverbMixLabel.setTopLeftPosition(reverbMixSlider.getX() + (reverbMixSlider.getWidth() - reverbMixLabel.getWidth()) / 2,
                                    reverbMixSlider.getY() - 25);

    reverbSliderArea.removeFromLeft(10); // Spacing

    auto reverbSizeBounds = reverbSliderArea.removeFromLeft(reverbSliderWidth);
     reverbSizeSlider.setBounds(reverbSizeBounds.withHeight(reverbSliderHeight)
                               .withY(reverbSizeBounds.getY() + (reverbSizeBounds.getHeight() - reverbSliderHeight) / 2));
    reverbSizeLabel.setTopLeftPosition(reverbSizeSlider.getX() + (reverbSizeSlider.getWidth() - reverbSizeLabel.getWidth()) / 2,
                                     reverbSizeSlider.getY() - 25);


    // Console Section (Center vertically stacked controls horizontally with rightward shift)
    auto consoleArea = fxArea.reduced(0, fxSectionPaddingY); // Remaining space
    auto consoleRowHeight = consoleArea.getHeight() / 2;
    
    // For the toggle button - shift from center
    auto consoleToggleBounds = consoleArea.removeFromTop(consoleRowHeight)
                                        .withSizeKeepingCentre(fxToggleWidth, consoleRowHeight * 0.6f);
    consoleToggleBounds.setX(consoleToggleBounds.getX() + rightShift); // Shift right
    consoleToggle.setBounds(consoleToggleBounds);
    
    // For the combo box - shift from center
    auto consoleModelBoxBounds = consoleArea.withSizeKeepingCentre(fxBoxWidth, consoleRowHeight * 0.6f);
    consoleModelBoxBounds.setX(consoleModelBoxBounds.getX() + rightShift); // Shift right
    consoleModelBox.setBounds(consoleModelBoxBounds);
    
    consoleModelLabel.setTopLeftPosition(consoleModelBox.getX() + (consoleModelBox.getWidth() - consoleModelLabel.getWidth()) / 2,
                                      consoleModelBox.getY() - 25); // Position label above centered box
}
