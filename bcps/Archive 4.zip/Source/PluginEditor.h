#pragma once

#include <JuceHeader.h>
#include "PluginProcessor.h"
#include <map>
#include <unordered_map>
#include <vector>
#include <string>

// Custom LookAndFeel for modern toggle buttons
class ModernToggleLookAndFeel : public juce::LookAndFeel_V4
{
public:
    void drawToggleButton(juce::Graphics& g, juce::ToggleButton& button,
                         bool shouldDrawButtonAsHighlighted, bool shouldDrawButtonAsDown) override
    {
        auto bounds = button.getLocalBounds().toFloat();
        const float width = bounds.getWidth();
        const float height = bounds.getHeight();
        
        // Calculate toggle switch bounds (right-aligned)
        const float toggleWidth = 40.0f;
        const float toggleHeight = 20.0f;
        const float textPadding = 15.0f;  // Add padding between text and toggle
        const float toggleX = width - toggleWidth - 5.0f;  // 5px padding from right
        const float toggleY = (height - toggleHeight) * 0.5f;
        
        juce::Rectangle<float> toggleBounds(toggleX, toggleY, toggleWidth, toggleHeight);
        
        // Draw text (left-aligned with more space)
        g.setColour(button.findColour(juce::ToggleButton::textColourId));
        g.setFont(16.0f);
        const float textWidth = toggleX - textPadding;  // Use all available space minus padding
        g.drawFittedText(button.getButtonText(), 0, 0, 
                      static_cast<int>(textWidth),
                      static_cast<int>(height),
                      juce::Justification::centredLeft, 1);

        // Get accent color based on button's section
        juce::Colour accentColor = button.findColour(juce::ToggleButton::tickColourId);
        
        // Draw toggle background
        const float cornerSize = toggleHeight * 0.5f;
        g.setColour(button.isEnabled() ? (button.isMouseOver() ? accentColor.withAlpha(0.2f) : 
                                        juce::Colour(40, 40, 45)) : 
                                        juce::Colour(30, 30, 35));
        g.fillRoundedRectangle(toggleBounds, cornerSize);
        
        // Draw toggle border
        g.setColour(button.isEnabled() ? (button.isMouseOver() ? accentColor : 
                                        juce::Colour(60, 60, 65)) : 
                                        juce::Colour(45, 45, 50));
        g.drawRoundedRectangle(toggleBounds, cornerSize, 1.0f);
        
        // Draw toggle switch (circle)
        const float switchDiameter = toggleHeight - 6.0f;
        const float switchX = button.getToggleState() ? 
                            (toggleX + toggleWidth - switchDiameter - 3.0f) : 
                            (toggleX + 3.0f);
        
        // Draw switch shadow
        g.setColour(juce::Colours::black.withAlpha(0.2f));
        g.fillEllipse(switchX + 1, toggleY + 4, switchDiameter, switchDiameter);
        
        // Draw switch
        g.setColour(button.getToggleState() ? accentColor : juce::Colour(180, 180, 185));
        g.fillEllipse(switchX, toggleY + 3, switchDiameter, switchDiameter);
        
        // Add highlight to switch
        g.setColour(juce::Colours::white.withAlpha(0.3f));
        g.fillEllipse(switchX + 2, toggleY + 5, switchDiameter * 0.5f, switchDiameter * 0.5f);
    }
};

class AllSynthPluginAudioProcessorEditor : public juce::AudioProcessorEditor
{
public:
    explicit AllSynthPluginAudioProcessorEditor(AllSynthPluginAudioProcessor&);
    ~AllSynthPluginAudioProcessorEditor() override
    {
        // Clean up custom LookAndFeel
        lfoToggle.setLookAndFeel(nullptr);
        noiseToggle.setLookAndFeel(nullptr);
        driveToggle.setLookAndFeel(nullptr);
        delayToggle.setLookAndFeel(nullptr);
        reverbToggle.setLookAndFeel(nullptr);
        delaySyncToggle.setLookAndFeel(nullptr);
        consoleToggle.setLookAndFeel(nullptr);
        oscSyncToggle.setLookAndFeel(nullptr);
    }

    void paint(juce::Graphics&) override;
    void resized() override;

private:
    AllSynthPluginAudioProcessor& processor;
    ModernToggleLookAndFeel modernToggleLookAndFeel; // Add instance of custom LookAndFeel

    // UI controls
    juce::Slider attackSlider, decaySlider, sustainSlider, releaseSlider;
    juce::Slider cutoffSlider, resonanceSlider;
    juce::ComboBox waveformBox, waveform2Box;  // 2nd osc selector
    juce::Slider pulseWidthSlider;
    // Volumes
    juce::Slider osc1VolSlider, osc2VolSlider;
    // NEW: Tuning sliders
    juce::Slider osc2DetuneSlider;
    juce::Slider osc1FineSlider, osc2FineSlider;
    juce::ComboBox modelBox;
    juce::ComboBox companyBox;
    // LFO
    juce::ToggleButton lfoToggle;
    juce::Slider       lfoRateSlider, lfoDepthSlider;
    // Noise & Drive
    juce::ToggleButton noiseToggle, driveToggle;
    juce::Slider       noiseMixSlider, driveAmtSlider;
    // FX
    juce::ToggleButton delayToggle, reverbToggle, delaySyncToggle;
    juce::Slider       delayMixSlider, reverbMixSlider, delayTimeSlider, delayFeedbackSlider;
    juce::Slider       reverbSizeSlider;    // NEW
    juce::ComboBox     reverbTypeBox;
    // Console
    juce::ToggleButton consoleToggle;
    juce::ComboBox     consoleModelBox;          // NEW
    juce::Label        consoleModelLabel;        // NEW

    // --- NEW: Preset selectors -----------------------------------------------
    juce::ComboBox presetCategoryBox, presetBox;
    juce::Label    presetCategoryLabel, presetLabel;
    // --- NEW: Arrow buttons ---
    juce::TextButton presetCategoryUpButton{ "^" }, presetCategoryDownButton{ "v" };
    juce::TextButton presetUpButton{ "^" }, presetDownButton{ "v" };
    juce::TextButton companyUpButton{ "^" }, companyDownButton{ "v" };
    juce::TextButton modelUpButton{ "^" }, modelDownButton{ "v" };
    // --------------------------

    // Labels
    juce::Label attackLabel, decayLabel, sustainLabel, releaseLabel;
    juce::Label cutoffLabel, resonanceLabel, waveformLabel, pulseWidthLabel, modelLabel;
    juce::Label companyLabel;
    juce::Label osc1VolLabel, osc2VolLabel, waveform2Label;
    // NEW: Tuning labels
    juce::Label osc2DetuneLabel, osc1FineLabel, osc2FineLabel;
    juce::Label lfoRateLabel, lfoDepthLabel, delayMixLabel, reverbMixLabel,
                delayTimeLabel, delayFbLabel;
    juce::Label noiseMixLabel, driveAmtLabel;
    juce::Label reverbSizeLabel, reverbTypeLabel;   // NEW size label

    // Attachments (unique_ptr)
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> attackAttachment, decayAttachment, sustainAttachment, releaseAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> cutoffAttachment, resonanceAttachment, pulseWidthAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> waveformAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> modelAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> osc1VolAttachment, osc2VolAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> waveform2Attachment;
    // NEW: Tuning attachments
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> osc2DetuneAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> osc1FineAttachment, osc2FineAttachment;
    // NEW: Osc Sync attachment
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>  oscSyncAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>  lfoToggleAttachment, delayToggleAttachment, reverbToggleAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>  lfoRateAttachment, lfoDepthAttachment,
                                                                          delayMixAttachment, reverbMixAttachment,
                                                                          reverbSizeAttachment,
                                                                          delayTimeAttachment, delayFbAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>  delaySyncAttachment;
    
    // Noise & Drive attachments
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>  noiseToggleAttachment, driveToggleAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>  noiseMixAttachment, driveAmtAttachment;
    // Console attachment
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>  consoleToggleAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> consoleModelAttachment; // NEW
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment>  reverbTypeAttachment; // NEW

    // Map of companies to synths and ID map
    std::map<std::string, std::vector<std::string>> companyToSynths;
    std::unordered_map<std::string, int> synthIdMap;

    // NEW ----------------------------------------------------------------------
    std::map<std::string, std::vector<int>> categoryToPresetIndices;
    void updatePresetDropDown(bool shouldLoadPreset = true);
    // -------------------------------------------------------------------------

    void updateModelList();

    // NEW ---------------------------------------------------------------------
    juce::ToggleButton oscSyncToggle;
    // -------------------------------------------------------------------------

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(AllSynthPluginAudioProcessorEditor)
}; 