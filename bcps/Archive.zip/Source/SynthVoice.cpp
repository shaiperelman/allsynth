#include "SynthVoice.h"
#include "SynthSound.h"

using namespace juce;

//==============================================================================
SynthVoice::SynthVoice(AudioProcessorValueTreeState& vts) : parameters(vts)
{
}

bool SynthVoice::canPlaySound(SynthesiserSound* sound)
{
    return dynamic_cast<SynthSound*>(sound) != nullptr;
}

void SynthVoice::prepare(double sampleRate, int samplesPerBlock, int /*outputChannels*/)
{
    currentSampleRate = sampleRate;

    dsp::ProcessSpec spec;
    spec.sampleRate = sampleRate;
    spec.maximumBlockSize = static_cast<uint32>(samplesPerBlock);
    spec.numChannels = 1;

    // Reset and prepare the filter chain
    filterChain.reset();
    filterChain.prepare(spec);
    
    // Configure the ladder filter in the chain
    auto& filter = filterChain.get<filterIndex>();
    filter.setMode(juce::dsp::LadderFilterMode::LPF24);

    // prepare state-variable filter
    svFilter.reset();
    svFilter.prepare(spec);
    svFilter.setType(juce::dsp::StateVariableTPTFilterType::lowpass);

    adsr.setSampleRate(sampleRate);

    updateParams();
}

void SynthVoice::startNote(int midiNoteNumber, float velocity, SynthesiserSound*, int /*currentPitchWheelPosition*/)
{
    adsr.noteOn();

    // Calculate initial phase increment per sample
    auto frequency = MidiMessage::getMidiNoteInHertz(midiNoteNumber);
    phase = 0.0;
    triangleIntegrator = 0.0f;       // reset our per-voice triangle integrator

    // NEW -----------------------------------------------------------------------
    phase2 = 0.0;
    triangleIntegrator2 = 0.0f;
    lfoPhase = 0.0;
    // ---------------------------------------------------------------------------

    ignoreUnused(velocity);
}

void SynthVoice::stopNote(float /*velocity*/, bool allowTailOff)
{
    adsr.noteOff();

    if (!allowTailOff || !adsr.isActive())
        clearCurrentNote();
}

float SynthVoice::computeOscSample()
{
    // PolyBLEP helper
    auto polyBlep = [](float t, float dt) noexcept -> float
    {
        if (t < dt) { 
            t /= dt; 
            return t + t - t * t - 1.0f; 
        }
        if (t > 1.0f - dt) { 
            t = (t - 1.0f) / dt; 
            return t * t + t + t + 1.0f; 
        }
        return 0.0f;
    };

    // Get parameters -----------------------------------------------------------
    int   wf1   = *parameters.getRawParameterValue("WAVEFORM");
    int   wf2   = *parameters.getRawParameterValue("WAVEFORM2");
    float pw    = *parameters.getRawParameterValue("PULSE_WIDTH");
    float vol1  = *parameters.getRawParameterValue("OSC1_VOLUME");
    float vol2  = *parameters.getRawParameterValue("OSC2_VOLUME");

    // LFO
    bool  lfoOn  = *parameters.getRawParameterValue("LFO_ON")  > 0.5f;
    float lfoRt  = *parameters.getRawParameterValue("LFO_RATE");
    float lfoDp  = *parameters.getRawParameterValue("LFO_DEPTH");

    // --------------------------------------------------------------------------
    const double baseFreq = juce::MidiMessage::getMidiNoteInHertz(getCurrentlyPlayingNote());
    const float  lfoVal   = lfoOn ? std::sin(juce::MathConstants<double>::twoPi * lfoPhase) * lfoDp
                                  : 0.0f;
    lfoPhase += lfoRt / currentSampleRate;
    if (lfoPhase >= 1.0) lfoPhase -= 1.0;

    const double freqMod = baseFreq * (1.0 + lfoVal);
    const double phaseInc = freqMod / currentSampleRate;
    const float  dt = static_cast<float>(phaseInc);

    auto singleOsc = [&](int waveform, double& ph, float& triInt) -> float
    {
        float s = 0.0f, t = static_cast<float>(ph);
        switch (waveform)
        {
            case 0: // Saw -------------------------------------------------------
                s = 2.0f * t - 1.0f;
                s -= polyBlep(t, dt);
                break;
            case 1: // Square 50% - improved anti-aliasing -----------------------
            {
                s = t < 0.5f ? 1.0f : -1.0f;
                s += polyBlep(t, dt);
                s -= polyBlep(std::fmod(t + 0.5f, 1.0f), dt);
                break;
            }
            case 2: // Pulse (uses global pw) -----------------------------------
                s = t < pw ? 1.0f : -1.0f;
                s += polyBlep(t, dt);
                s -= polyBlep(std::fmod(t + (1.0f - pw), 1.0f), dt);
                break;
            case 3: // Triangle - using Poly-BLAMP method -----------------------
            {
                // BLAMP method - difference of two saw waves
                float saw1 = 2.0f * t - 1.0f - polyBlep(t, dt);
                float t2 = std::fmod(t + 0.5f, 1.0f);
                float saw2 = 2.0f * t2 - 1.0f - polyBlep(t2, dt);
                s = 0.5f * (saw1 - saw2);
                break;
            }
            default: break;
        }

        ph += phaseInc;
        if (ph >= 1.0) ph -= 1.0;
        return s;
    };

    float osc1 = singleOsc(wf1, phase , triangleIntegrator );
    float osc2 = singleOsc(wf2, phase2, triangleIntegrator2);

    float out = osc1 * vol1 + osc2 * vol2;
    
    // Add noise if enabled
    if (noiseOn)
        out = out * (1.0f - noiseMix) + (rnd.nextFloat() * 2.0f - 1.0f) * noiseMix;

    return out;
}

void SynthVoice::renderNextBlock(AudioBuffer<float>& outputBuffer, int startSample, int numSamples)
{
    if (!isVoiceActive())
        return;

    updateParams();

    const bool useSVF = (currentModel == 2 || currentModel == 3 || currentModel == 6);

    if (!useSVF)
    {
        // Revert back to Ladder filter path: buffer then chain
        juce::AudioBuffer<float> tempBuffer;
        tempBuffer.setSize(1, numSamples); // Mono processing for the chain
        tempBuffer.clear();

        // Fill temp buffer with oscillator output
        for (int sample = 0; sample < numSamples; ++sample)
        {
            float oscSample = computeOscSample();
            tempBuffer.setSample(0, sample, oscSample);
        }

        // Process the buffer through the filter chain
        juce::dsp::AudioBlock<float> block(tempBuffer);
        juce::dsp::ProcessContextReplacing<float> context(block);
        filterChain.process(context);

        // Apply ADSR and copy to output buffer
        for (int sample = 0; sample < numSamples; ++sample)
        {
            float filtered = tempBuffer.getSample(0, sample);
            float env = adsr.getNextSample();
            float currentSample = filtered * env;

            // Add to all output channels
            for (int channel = 0; channel < outputBuffer.getNumChannels(); ++channel)
                outputBuffer.addSample(channel, startSample + sample, currentSample);
        }
    }
    else // State Variable Filter path (remains unchanged)
    {
        for (int sample = 0; sample < numSamples; ++sample)
        {
            float osc = computeOscSample();
            float filt = svFilter.processSample(0, osc);
            filt = std::tanh(1.4f * filt);     // simple drive
            float env = adsr.getNextSample();
            float currentSample = filt * env;

            for (int channel = 0; channel < outputBuffer.getNumChannels(); ++channel)
                outputBuffer.addSample(channel, startSample + sample, currentSample);
        }
    }

    if (!adsr.isActive())
        clearCurrentNote();
}

void SynthVoice::updateParams()
{
    // Get parameters
    const float cutoff    = *parameters.getRawParameterValue("CUTOFF");
    const float resonance = *parameters.getRawParameterValue("RESONANCE");
    currentModel          = *parameters.getRawParameterValue("MODEL");

    // Noise parameters
    noiseOn  = *parameters.getRawParameterValue("NOISE_ON") > 0.5f;
    noiseMix = *parameters.getRawParameterValue("NOISE_MIX");

    // Smooth parameter changes
    cutoffSmoothed   .setTargetValue(cutoff);
    resonanceSmoothed.setTargetValue(resonance);
    
    // Get references to processors in the chain
    auto& gain   = filterChain.get<gainIndex>();
    auto& ladder = filterChain.get<filterIndex>();
    auto& drive  = filterChain.get<shaperIndex>();
    
    // Configure based on synth model
    switch (currentModel)
    {
        case 0: // Minimoog
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.4f);
            gain .setGainLinear(0.9f);
            drive.functionToUse = [](float x) { return std::tanh(1.6f * x); };
            break;
        case 1: // Prodigy
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.1f);
            gain .setGainLinear(0.9f);
            drive.functionToUse = [](float x) { return std::tanh(1.3f * x); };
            break;
        case 2: // ARP 2600
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x) { return std::tanh(1.2f * x); };
            break;
        case 3: // Odyssey
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x) { return std::tanh(1.4f * x); };
            break;
        case 4: // CS-80
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x) { return std::tanh(1.25f * x); };
            break;
        case 5: // Jupiter-4
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x) { return std::tanh(1.30f * x); };
            break;
        case 6: // MS-20
            gain .setGainLinear(1.1f);
            drive.functionToUse = [](float x) { return std::tanh(1.50f * x); };
            break;
        case 7: // Polymoog
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x) { return std::tanh(1.10f * x); };
            break;
        case 8: // OB-X
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x) { return std::tanh(1.40f * x); };
            break;
        case 9: // Prophet‑5
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.30f);
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x){ return std::tanh(1.25f * x); };
            break;
        case 10: // Taurus
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.60f);
            gain .setGainLinear(1.1f);
            drive.functionToUse = [](float x){ return std::tanh(1.55f * x); };
            break;
        case 11: // Model D
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.40f);
            gain .setGainLinear(0.95f);
            drive.functionToUse = [](float x){ return std::tanh(1.45f * x); };
            break;
        case 12: // SH‑101
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.20f);
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x){ return std::tanh(1.20f * x); };
            break;
        case 13: // Juno‑60
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.15f);
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x){ return std::tanh(1.15f * x); };
            break;
        case 14: // MonoPoly
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.30f);
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x){ return std::tanh(1.30f * x); };
            break;
        case 15: // Voyager
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.35f);
            gain .setGainLinear(0.95f);
            drive.functionToUse = [](float x){ return std::tanh(1.40f * x); };
            break;
        case 16: // Prophet‑6
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.25f);
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x){ return std::tanh(1.25f * x); };
            break;
        case 17: // Jupiter‑8
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.30f);
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x){ return std::tanh(1.30f * x); };
            break;
        case 18: // Polysix
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.25f);
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x){ return std::tanh(1.25f * x); };
            break;
        case 19: // Matrix‑12
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.20f);
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x){ return std::tanh(1.20f * x); };
            break;
        case 20: // PPG Wave
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.15f);
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x){ return std::tanh(1.15f * x); };
            break;
        case 21: // OB‑6
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.25f);
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x){ return std::tanh(1.25f * x); };
            break;
        case 22: // DX7
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.00f);
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x){ return x; };
            break;
        case 23: // Virus
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.30f);
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x){ return std::tanh(1.35f * x); };
            break;
        case 24: // D‑50
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.10f);
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x){ return x; };
            break;
        case 25: // Memorymoog
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.35f);
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x){ return std::tanh(1.35f * x); };
            break;
        case 26: // Minilogue
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.20f);
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x){ return std::tanh(1.20f * x); };
            break;
        case 27: // Sub 37
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.45f);
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x){ return std::tanh(1.45f * x); };
            break;
        case 28: // Nord Lead 2
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.05f);
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x){ return std::tanh(1.05f * x); };
            break;
        case 29: // Blofeld
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.10f);
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x){ return std::tanh(1.10f * x); };
            break;
        case 30: // Prophet VS
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.15f);
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x){ return std::tanh(1.15f * x); };
            break;
        case 31: // Prophet‑10
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.25f);
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x){ return std::tanh(1.25f * x); };
            break;
        case 32: // JX‑8P
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.10f);
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x){ return std::tanh(1.10f * x); };
            break;
        case 33: // CZ‑101
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.00f);
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x){ return x; };
            break;
        case 34: // ESQ‑1
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.10f);
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x){ return std::tanh(1.10f * x); };
            break;
        case 35: // System‑8
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.20f);
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x){ return std::tanh(1.20f * x); };
            break;
        case 36: // Massive
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.00f);
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x){ return x; };
            break;
        case 37: // MicroFreak
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.15f);
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x){ return std::tanh(1.15f * x); };
            break;
        case 38: // Analog Four
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.30f);
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x){ return std::tanh(1.30f * x); };
            break;
        case 39: // MicroKorg
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.10f);
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x){ return std::tanh(1.10f * x); };
            break;
        // ---------- EXTRA MODELS ----------
        case 40: // TB‑303
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.40f);
            gain .setGainLinear(1.05f);
            drive.functionToUse = [](float x){ return std::tanh(1.40f * x); };
            break;
        case 41: // JP‑8000
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.25f);
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x){ return std::tanh(1.25f * x); };
            break;
        case 42: // M1
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.00f);
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x){ return x; };
            break;
        case 43: // Wavestation
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.05f);
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x){ return x; };
            break;
        case 44: // JD‑800
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.15f);
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x){ return std::tanh(1.15f * x); };
            break;
        case 45: // Hydrasynth
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.10f);
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x){ return std::tanh(1.10f * x); };
            break;
        case 46: // PolyBrute
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.30f);
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x){ return std::tanh(1.30f * x); };
            break;
        case 47: // Matriarch
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.35f);
            gain .setGainLinear(1.05f);
            drive.functionToUse = [](float x){ return std::tanh(1.35f * x); };
            break;
        case 48: // Kronos
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.00f);
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x){ return x; };
            break;
        case 49: // Prophet‑12
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.25f);
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x){ return std::tanh(1.25f * x); };
            break;

        // ---------- any ID ≥ 50 falls through here -----------------
        default:
            ladder.setMode(juce::dsp::LadderFilterMode::LPF24);
            ladder.setDrive(1.25f);
            gain .setGainLinear(1.0f);
            drive.functionToUse = [](float x){ return std::tanh(1.25f * x); };
            break;
    }
    
    // Update filter parameters
    ladder.setCutoffFrequencyHz(cutoffSmoothed.getNextValue());
    ladder.setResonance(resonanceSmoothed.getNextValue());
    
    svFilter.setCutoffFrequency(cutoffSmoothed.getCurrentValue());
    svFilter.setResonance(resonanceSmoothed.getCurrentValue());

    // ADSR
    adsrParams.attack = *parameters.getRawParameterValue("ATTACK");
    adsrParams.decay = *parameters.getRawParameterValue("DECAY");
    adsrParams.sustain = *parameters.getRawParameterValue("SUSTAIN");
    adsrParams.release = *parameters.getRawParameterValue("RELEASE");

    adsr.setParameters(adsrParams);
} 