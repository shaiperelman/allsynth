#include "PluginProcessor.h"
#include "PluginEditor.h"

AllSynthPluginAudioProcessorEditor::AllSynthPluginAudioProcessorEditor(AllSynthPluginAudioProcessor& p)
    : AudioProcessorEditor(&p), processor(p)
{
    auto& vts = processor.getValueTreeState();

    // --- Envelope Section ---
    attackSlider.setSliderStyle(juce::Slider::SliderStyle::RotaryVerticalDrag);
    attackSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 20);
    addAndMakeVisible(attackSlider);
    attackLabel.setText("Attack", juce::dontSendNotification);
    attackLabel.attachToComponent(&attackSlider, false);
    attackLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(attackLabel);
    attackAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts, "ATTACK", attackSlider);

    decaySlider.setSliderStyle(juce::Slider::SliderStyle::RotaryVerticalDrag);
    decaySlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 20);
    addAndMakeVisible(decaySlider);
    decayLabel.setText("Decay", juce::dontSendNotification);
    decayLabel.attachToComponent(&decaySlider, false);
    decayLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(decayLabel);
    decayAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts, "DECAY", decaySlider);

    sustainSlider.setSliderStyle(juce::Slider::SliderStyle::RotaryVerticalDrag);
    sustainSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 20);
    addAndMakeVisible(sustainSlider);
    sustainLabel.setText("Sustain", juce::dontSendNotification);
    sustainLabel.attachToComponent(&sustainSlider, false);
    sustainLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(sustainLabel);
    sustainAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts, "SUSTAIN", sustainSlider);

    releaseSlider.setSliderStyle(juce::Slider::SliderStyle::RotaryVerticalDrag);
    releaseSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 20);
    addAndMakeVisible(releaseSlider);
    releaseLabel.setText("Release", juce::dontSendNotification);
    releaseLabel.attachToComponent(&releaseSlider, false);
    releaseLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(releaseLabel);
    releaseAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts, "RELEASE", releaseSlider);

    // --- Filter Section ---
    cutoffSlider.setSliderStyle(juce::Slider::SliderStyle::RotaryVerticalDrag);
    cutoffSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 20);
    addAndMakeVisible(cutoffSlider);
    cutoffLabel.setText("Cutoff", juce::dontSendNotification);
    cutoffLabel.attachToComponent(&cutoffSlider, false);
    cutoffLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(cutoffLabel);
    cutoffAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts, "CUTOFF", cutoffSlider);

    resonanceSlider.setSliderStyle(juce::Slider::SliderStyle::RotaryVerticalDrag);
    resonanceSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 20);
    addAndMakeVisible(resonanceSlider);
    resonanceLabel.setText("Resonance", juce::dontSendNotification);
    resonanceLabel.attachToComponent(&resonanceSlider, false);
    resonanceLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(resonanceLabel);
    resonanceAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts, "RESONANCE", resonanceSlider);

    // --- Oscillator Section ---
    waveformBox.addItemList({"Saw", "Square", "Pulse", "Triangle"}, 1);
    addAndMakeVisible(waveformBox);
    waveformLabel.setText("Waveform", juce::dontSendNotification);
    waveformLabel.attachToComponent(&waveformBox, false);
    waveformLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(waveformLabel);
    waveformAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(vts, "WAVEFORM", waveformBox);

    pulseWidthSlider.setSliderStyle(juce::Slider::SliderStyle::LinearHorizontal);
    pulseWidthSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 20);
    // Initially hide pulse width, only show if Square is selected
    // pulseWidthSlider.setVisible(false); // We'll handle visibility later if needed
    addAndMakeVisible(pulseWidthSlider);
    pulseWidthLabel.setText("Pulse Width", juce::dontSendNotification);
    pulseWidthLabel.attachToComponent(&pulseWidthSlider, false);
    pulseWidthLabel.setJustificationType(juce::Justification::centredBottom);
    // pulseWidthLabel.setVisible(false); // We'll handle visibility later if needed
    addAndMakeVisible(pulseWidthLabel);
    pulseWidthAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts, "PULSE_WIDTH", pulseWidthSlider);

    // --- Model Section ---
    modelBox.addItemList(
        {"Minimoog","Prodigy","ARP 2600","Odyssey",
         "CS-80","Jupiter-4","MS-20","Polymoog","OB-X",
         "Prophet-5","Taurus","Model D",
         "SH-101","Juno-60","MonoPoly"},
        1);
    addAndMakeVisible(modelBox);
    modelLabel.setText("Synth Model", juce::dontSendNotification);
    modelLabel.attachToComponent(&modelBox, false); // Attach above
    modelLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(modelLabel);
    modelAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(vts, "MODEL", modelBox); // Changed ID


    // Set editor size
    setSize(600, 400); // Adjust size as needed
}

// Destructor is defaulted in the header

void AllSynthPluginAudioProcessorEditor::paint(juce::Graphics& g)
{
    // Modern gradient background
    juce::ColourGradient grad(juce::Colours::darkslategrey, 0, 0,
                              juce::Colours::black, (float)getWidth(), (float)getHeight(), true);
    g.setGradientFill(grad);
    g.fillRect(getLocalBounds());

    // Header text
    g.setColour(juce::Colours::white.withAlpha(0.9f));
    g.setFont(juce::Font(28.0f, juce::Font::bold));
    g.drawText("AllSynth v1.0", getLocalBounds().removeFromTop(60), juce::Justification::centred);
}

void AllSynthPluginAudioProcessorEditor::resized()
{
    using Track = juce::Grid::TrackInfo;
    juce::Grid grid;

    // Define a 4-column, 4-row grid: top row for header, then control grid
    grid.templateColumns = { Track(juce::Grid::Fr(1)), Track(juce::Grid::Fr(1)), Track(juce::Grid::Fr(1)), Track(juce::Grid::Fr(1)) };
    grid.templateRows    = { Track(60), Track(juce::Grid::Fr(2)), Track(juce::Grid::Fr(2)), Track(juce::Grid::Fr(2)) };
    grid.autoFlow = juce::Grid::AutoFlow::row;

    // Place controls in the grid
    grid.items = {
        // Model selector spans entire top of control area
        juce::GridItem(modelBox).withArea(1, 1, 1, 4),

        // Oscillator controls
        juce::GridItem(waveformBox)    .withArea(2, 1, 1, 1),
        juce::GridItem(pulseWidthSlider).withArea(2, 2, 1, 1),

        // Filter controls
        juce::GridItem(cutoffSlider)   .withArea(2, 3, 1, 1),
        juce::GridItem(resonanceSlider).withArea(2, 4, 1, 1),

        // Envelope controls
        juce::GridItem(attackSlider)   .withArea(3, 1, 1, 1),
        juce::GridItem(decaySlider)    .withArea(3, 2, 1, 1),
        juce::GridItem(sustainSlider)  .withArea(3, 3, 1, 1),
        juce::GridItem(releaseSlider)  .withArea(3, 4, 1, 1),
    };

    // Perform layout
    grid.performLayout(getLocalBounds());
}


