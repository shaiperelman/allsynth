#pragma once

#include <JuceHeader.h>
#include "PluginProcessor.h"

class AllSynthPluginAudioProcessorEditor : public juce::AudioProcessorEditor
{
public:
    explicit AllSynthPluginAudioProcessorEditor(AllSynthPluginAudioProcessor&);
    ~AllSynthPluginAudioProcessorEditor() override = default;

    void paint(juce::Graphics&) override;
    void resized() override;

private:
    AllSynthPluginAudioProcessor& processor;

    // UI controls
    juce::Slider attackSlider, decaySlider, sustainSlider, releaseSlider;
    juce::Slider cutoffSlider, resonanceSlider;
    juce::ComboBox waveformBox;
    juce::Slider pulseWidthSlider;
    juce::ComboBox modelBox;

    // Labels
    juce::Label attackLabel, decayLabel, sustainLabel, releaseLabel;
    juce::Label cutoffLabel, resonanceLabel, waveformLabel, pulseWidthLabel, modelLabel;

    // Attachments (unique_ptr)
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> attackAttachment, decayAttachment, sustainAttachment, releaseAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> cutoffAttachment, resonanceAttachment, pulseWidthAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> waveformAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> modelAttachment;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(AllSynthPluginAudioProcessorEditor)
}; 