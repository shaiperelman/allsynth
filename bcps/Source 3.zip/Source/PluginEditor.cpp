#include "PluginProcessor.h"
#include "PluginEditor.h"

AllSynthPluginAudioProcessorEditor::AllSynthPluginAudioProcessorEditor(AllSynthPluginAudioProcessor& p)
    : AudioProcessorEditor(&p), processor(p)
{
    auto& vts = processor.getValueTreeState();

    // --- Setup data structures ---
    struct SynthEntry { const char* name; const char* company; };
    const SynthEntry synthModels[] = {
        {"Minimoog","Moog"},{"Prodigy","Moog"},{"Taurus","Moog"},{"Model D","Moog"},{"Memorymoog","Moog"},{"Sub 37","Moog"},{"Matriarch","Moog"},
        {"ARP 2600","ARP"},{"Odyssey","ARP"},
        {"CS-80","Yamaha"},{"DX7","Yamaha"},
        {"Jupiter-4","Roland"},{"Jupiter-8","Roland"},{"SH-101","Roland"},{"Juno-60","Roland"},{"TB-303","Roland"},{"JP-8000","Roland"},{"JD-800","Roland"},
        {"M1","Korg"},{"Wavestation","Korg"},{"Kronos","Korg"},{"MS-20","Korg"},{"Polysix","Korg"},{"MonoPoly","Korg"},{"Minilogue","Korg"},{"MicroKorg","Korg"},
        {"Prophet-5","Sequential"},{"Prophet-6","Sequential"},{"Prophet-10","Sequential"},{"Prophet-12","Sequential"},{"Prophet VS","Sequential"},
        {"OB-X","Oberheim"},{"OB-6","Oberheim"},{"Matrix-12","Oberheim"},
        {"PolyBrute","Arturia"},{"MicroFreak","Arturia"},{"Analog Four","Elektron"},{"Massive","Native Instruments"},{"Nord Lead 2","Clavia"},{"Blofeld","Waldorf"},
        {"PPG Wave","PPG"},{"CZ-101","Casio"},{"ESQ-1","Ensoniq"},{"Hydrasynth","ASM"}
    };
    // build map
    for (auto& e : synthModels) companyToSynths[e.company].push_back(e.name);
    // build id map from parameter choices
    if (auto* param = dynamic_cast<juce::AudioParameterChoice*>(vts.getParameter("MODEL")))
        for (int i=0;i<param->choices.size();++i) synthIdMap[param->choices[i].toStdString()] = i+1;
    // Company dropdown
    int cid=1; for (auto& cp: companyToSynths) companyBox.addItem(cp.first, cid++);
    companyBox.onChange = [this] { updateModelList(); };
    addAndMakeVisible(companyBox);
    companyLabel.setText("Company", juce::dontSendNotification);
    companyLabel.attachToComponent(&companyBox, false);
    companyLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(companyLabel);
    companyBox.setColour(juce::ComboBox::backgroundColourId, juce::Colour(30,30,30));
    companyBox.setColour(juce::ComboBox::textColourId, juce::Colours::white);
    companyBox.setSelectedId(1);
    // initial model list
    updateModelList();

    // --- Envelope Section ---
    attackSlider.setSliderStyle(juce::Slider::SliderStyle::RotaryVerticalDrag);
    attackSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 20);
    addAndMakeVisible(attackSlider);
    attackLabel.setText("Attack", juce::dontSendNotification);
    attackLabel.attachToComponent(&attackSlider, false);
    attackLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(attackLabel);
    attackAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts, "ATTACK", attackSlider);

    decaySlider.setSliderStyle(juce::Slider::SliderStyle::RotaryVerticalDrag);
    decaySlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 20);
    addAndMakeVisible(decaySlider);
    decayLabel.setText("Decay", juce::dontSendNotification);
    decayLabel.attachToComponent(&decaySlider, false);
    decayLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(decayLabel);
    decayAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts, "DECAY", decaySlider);

    sustainSlider.setSliderStyle(juce::Slider::SliderStyle::RotaryVerticalDrag);
    sustainSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 20);
    addAndMakeVisible(sustainSlider);
    sustainLabel.setText("Sustain", juce::dontSendNotification);
    sustainLabel.attachToComponent(&sustainSlider, false);
    sustainLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(sustainLabel);
    sustainAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts, "SUSTAIN", sustainSlider);

    releaseSlider.setSliderStyle(juce::Slider::SliderStyle::RotaryVerticalDrag);
    releaseSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 20);
    addAndMakeVisible(releaseSlider);
    releaseLabel.setText("Release", juce::dontSendNotification);
    releaseLabel.attachToComponent(&releaseSlider, false);
    releaseLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(releaseLabel);
    releaseAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts, "RELEASE", releaseSlider);

    // --- Filter Section ---
    cutoffSlider.setSliderStyle(juce::Slider::SliderStyle::RotaryVerticalDrag);
    cutoffSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 20);
    addAndMakeVisible(cutoffSlider);
    cutoffLabel.setText("Cutoff", juce::dontSendNotification);
    cutoffLabel.attachToComponent(&cutoffSlider, false);
    cutoffLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(cutoffLabel);
    cutoffAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts, "CUTOFF", cutoffSlider);

    resonanceSlider.setSliderStyle(juce::Slider::SliderStyle::RotaryVerticalDrag);
    resonanceSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 20);
    addAndMakeVisible(resonanceSlider);
    resonanceLabel.setText("Resonance", juce::dontSendNotification);
    resonanceLabel.attachToComponent(&resonanceSlider, false);
    resonanceLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(resonanceLabel);
    resonanceAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts, "RESONANCE", resonanceSlider);

    // --- Oscillator Section ---
    waveformBox.addItemList({"Saw", "Square", "Pulse", "Triangle"}, 1);
    addAndMakeVisible(waveformBox);
    waveformLabel.setText("Waveform", juce::dontSendNotification);
    waveformLabel.attachToComponent(&waveformBox, false);
    waveformLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(waveformLabel);
    waveformAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(vts, "WAVEFORM", waveformBox);

    pulseWidthSlider.setSliderStyle(juce::Slider::SliderStyle::LinearHorizontal);
    pulseWidthSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 20);
    // Initially hide pulse width, only show if Square is selected
    // pulseWidthSlider.setVisible(false); // We'll handle visibility later if needed
    addAndMakeVisible(pulseWidthSlider);
    pulseWidthLabel.setText("Pulse Width", juce::dontSendNotification);
    pulseWidthLabel.attachToComponent(&pulseWidthSlider, false);
    pulseWidthLabel.setJustificationType(juce::Justification::centredBottom);
    // pulseWidthLabel.setVisible(false); // We'll handle visibility later if needed
    addAndMakeVisible(pulseWidthLabel);
    pulseWidthAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts, "PULSE_WIDTH", pulseWidthSlider);

    // --- Model Section ---
    modelBox.addSectionHeading("Moog");
    modelBox.addItem("Minimoog", 1);
    modelBox.addItem("Prodigy", 2);
    modelBox.addItem("Taurus", 3);
    modelBox.addItem("Model D", 4);
    modelBox.addItem("Memorymoog", 5);
    modelBox.addItem("Sub 37", 6);
    modelBox.addItem("Matriarch", 7);
    modelBox.addSectionHeading("ARP");
    modelBox.addItem("ARP 2600", 8);
    modelBox.addItem("Odyssey", 9);
    modelBox.addSectionHeading("Yamaha");
    modelBox.addItem("CS-80", 10);
    modelBox.addItem("DX7", 11);
    modelBox.addSectionHeading("Roland");
    modelBox.addItem("Jupiter-4", 12);
    modelBox.addItem("Jupiter-8", 13);
    modelBox.addItem("SH-101", 14);
    modelBox.addItem("Juno-60", 15);
    modelBox.addItem("TB-303", 16);
    modelBox.addItem("JP-8000", 17);
    modelBox.addItem("JD-800", 18);
    modelBox.addSectionHeading("Korg");
    modelBox.addItem("M1", 19);
    modelBox.addItem("Wavestation", 20);
    modelBox.addItem("Kronos", 21);
    modelBox.addItem("MS-20", 22);
    modelBox.addItem("Polysix", 23);
    modelBox.addItem("MonoPoly", 24);
    modelBox.addItem("Minilogue", 25);
    modelBox.addItem("MicroKorg", 26);
    modelBox.addSectionHeading("Sequential");
    modelBox.addItem("Prophet-5", 27);
    modelBox.addItem("Prophet-6", 28);
    modelBox.addItem("Prophet-10", 29);
    modelBox.addItem("Prophet-12", 30);
    modelBox.addItem("Prophet VS", 31);
    modelBox.addSectionHeading("Oberheim");
    modelBox.addItem("OB-X", 32);
    modelBox.addItem("OB-6", 33);
    modelBox.addItem("Matrix-12", 34);
    modelBox.addSectionHeading("Arturia");
    modelBox.addItem("PolyBrute", 35);
    modelBox.addItem("MicroFreak", 36);
    modelBox.addSectionHeading("Elektron");
    modelBox.addItem("Analog Four", 37);
    modelBox.addSectionHeading("Native Instruments");
    modelBox.addItem("Massive", 38);
    modelBox.addSectionHeading("Clavia");
    modelBox.addItem("Nord Lead 2", 39);
    modelBox.addSectionHeading("Waldorf");
    modelBox.addItem("Blofeld", 40);
    modelBox.addSectionHeading("PPG");
    modelBox.addItem("PPG Wave", 41);
    modelBox.addSectionHeading("Casio");
    modelBox.addItem("CZ-101", 42);
    modelBox.addSectionHeading("Ensoniq");
    modelBox.addItem("ESQ-1", 43);
    modelBox.addSectionHeading("ASM");
    modelBox.addItem("Hydrasynth", 44);
    addAndMakeVisible(modelBox);
    modelLabel.setText("Synth Model", juce::dontSendNotification);
    modelLabel.attachToComponent(&modelBox, false); // Attach above
    modelLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(modelLabel);
    modelAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(vts, "MODEL", modelBox);

    // style
    setSize(600,400);
    getLookAndFeel().setColour(juce::ResizableWindow::backgroundColourId, juce::Colours::black);
    for (auto* lbl: {&attackLabel,&decayLabel,&sustainLabel,&releaseLabel,&cutoffLabel,&resonanceLabel,&waveformLabel,&pulseWidthLabel,&companyLabel,&modelLabel})
        lbl->setColour(juce::Label::textColourId, juce::Colours::white);
    for (auto* cb: {&companyBox,&modelBox,&waveformBox}) {
        cb->setColour(juce::ComboBox::backgroundColourId, juce::Colour(50,50,50));
        cb->setColour(juce::ComboBox::textColourId, juce::Colours::white);
    }
    for (auto* sw: {&attackSlider,&decaySlider,&sustainSlider,&releaseSlider,&cutoffSlider,&resonanceSlider,&pulseWidthSlider})
        sw->setColour(juce::Slider::thumbColourId, juce::Colours::cyan);
}

//==============================================================================
void AllSynthPluginAudioProcessorEditor::updateModelList()
{
    // Filter models by selected company
    auto compName = companyBox.getText().toStdString();
    modelBox.clear(juce::dontSendNotification);
    if (companyToSynths.count(compName) > 0) {
        for (auto& synth : companyToSynths[compName]) {
            auto it = synthIdMap.find(synth);
            if (it != synthIdMap.end())
                modelBox.addItem(synth, it->second);
        }
    }
    // Ensure first item selected
    if (modelBox.getNumItems() > 0)
        modelBox.setSelectedId(modelBox.getItemId(0), juce::dontSendNotification);
}

// Destructor is defaulted in the header

void AllSynthPluginAudioProcessorEditor::paint(juce::Graphics& g)
{
    // Fill the background
    g.fillAll(getLookAndFeel().findColour(juce::ResizableWindow::backgroundColourId));

    // Optional: Draw some text or decorations
    g.setColour(juce::Colours::white);
    g.setFont(15.0f);
    // g.drawFittedText("AllSynth v1.0", getLocalBounds(), juce::Justification::centredTop, 1);
}

void AllSynthPluginAudioProcessorEditor::resized()
{
    // Define the layout areas
    auto bounds = getLocalBounds().reduced(10); // Add some margin
    // Company filter area
    auto companyArea = bounds.removeFromTop(40);
    companyBox.setBounds(companyArea.removeFromLeft(240).reduced(10));
    // rest of UI below company dropdown
    auto topArea = bounds.removeFromTop(bounds.getHeight() / 3);
    auto midArea = bounds.removeFromTop(bounds.getHeight() / 2); // Middle half of remaining
    auto bottomArea = bounds;                                 // Rest is bottom

    // --- Top Area: Model and Oscillator ---
    auto modelArea = topArea.removeFromLeft(topArea.getWidth() / 3);
    auto oscArea = topArea; // Remaining space in top area

    // Model layout
    modelBox.setBounds(modelArea.reduced(10, 30)); // Reduce for label space
    // Waveform layout
    waveformBox.setBounds(oscArea.removeFromLeft(oscArea.getWidth() / 2).reduced(10, 30));
    // Pulse width layout
    pulseWidthSlider.setBounds(oscArea.reduced(10, 30));

    // --- Mid Area: Filter ---
    auto filterArea = midArea;
    auto cutoffArea = filterArea.removeFromLeft(filterArea.getWidth() / 2);
    auto resonanceArea = filterArea;

    cutoffSlider.setBounds(cutoffArea.reduced(20));
    resonanceSlider.setBounds(resonanceArea.reduced(20));

    // --- Bottom Area: Envelope ---
    auto envArea = bottomArea;
    const int numEnvSliders = 4;
    auto sliderWidth = envArea.getWidth() / numEnvSliders;

    attackSlider.setBounds(envArea.removeFromLeft(sliderWidth).reduced(20));
    decaySlider.setBounds(envArea.removeFromLeft(sliderWidth).reduced(20));
    sustainSlider.setBounds(envArea.removeFromLeft(sliderWidth).reduced(20));
    releaseSlider.setBounds(envArea.removeFromLeft(sliderWidth).reduced(20));

    // Labels are attached, so their positions are relative to their components
}
