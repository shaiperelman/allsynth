#include "PluginProcessor.h"
#include "PluginEditor.h"
#include "SynthSound.h"
#include "SynthVoice.h"

AllSynthPluginAudioProcessor::AllSynthPluginAudioProcessor()
    : AudioProcessor(BusesProperties()
#if ! JucePlugin_IsMidiEffect
#if ! JucePlugin_IsSynth
                         .withInput("Input", juce::AudioChannelSet::stereo(), true)
#endif
                         .withOutput("Output", juce::AudioChannelSet::stereo(), true)
#endif
      ),
      parameters(*this, nullptr, juce::Identifier("AllSynthParams"), createParameterLayout())
{
    // Create voices and sound
    const int numVoices = 8;
    for (int i = 0; i < numVoices; ++i)
        synth.addVoice(new SynthVoice(parameters));

    synth.addSound(new SynthSound());
}

//==============================================================================
juce::AudioProcessorValueTreeState::ParameterLayout AllSynthPluginAudioProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    // Synth model selection
    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        "MODEL",
        "Synth Model",
        juce::StringArray{
            "Minimoog","Prodigy","ARP 2600","Odyssey",
            "CS-80","Jupiter-4","MS-20","Polymoog","OB-X",
            "Prophet-5","Taurus","Model D",
            "SH-101","Juno-60","MonoPoly",
            "Voyager","Prophet-6","Jupiter-8","Polysix","Matrix-12",
            "PPG Wave","OB-6","DX7","Virus","D-50",
            "Memorymoog","Minilogue","Sub 37","Nord Lead 2","Blofeld",
            "Prophet VS","Prophet-10","JX-8P","CZ-101","ESQ-1",
            "System-8","Massive","MicroFreak","Analog Four","MicroKorg",
            "TB-303","JP-8000","M1","Wavestation","JD-800",
            "Hydrasynth","PolyBrute","Matriarch","Kronos","Prophet-12"},
        0));

    // Waveform selection: 0=Saw,1=Square,2=Pulse,3=Triangle
    params.push_back(std::make_unique<juce::AudioParameterChoice>("WAVEFORM", "Waveform", juce::StringArray({"Saw", "Square", "Pulse", "Triangle"}), 0));

    // Pulse width (used when waveform is pulse)
    params.push_back(std::make_unique<juce::AudioParameterFloat>("PULSE_WIDTH", "Pulse Width", juce::NormalisableRange<float>(0.05f, 0.95f, 0.001f), 0.5f));

    // Filter cutoff and resonance
    params.push_back(std::make_unique<juce::AudioParameterFloat>("CUTOFF", "Cutoff", juce::NormalisableRange<float>(20.0f, 20000.0f, 0.01f, 0.5f), 20000.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>("RESONANCE", "Resonance", juce::NormalisableRange<float>(0.1f, 10.0f, 0.01f, 0.5f), 0.7f));

    // ADSR envelope
    params.push_back(std::make_unique<juce::AudioParameterFloat>("ATTACK", "Attack", juce::NormalisableRange<float>(0.001f, 5.0f, 0.001f, 0.5f), 0.01f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>("DECAY", "Decay", juce::NormalisableRange<float>(0.001f, 5.0f, 0.001f, 0.5f), 0.1f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>("SUSTAIN", "Sustain", juce::NormalisableRange<float>(0.0f, 1.0f, 0.001f), 0.8f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>("RELEASE", "Release", juce::NormalisableRange<float>(0.001f, 10.0f, 0.001f, 0.5f), 0.2f));

    return { params.begin(), params.end() };
}

//==============================================================================
void AllSynthPluginAudioProcessor::prepareToPlay(double sampleRate, int samplesPerBlock)
{
    synth.setCurrentPlaybackSampleRate(sampleRate);

    for (int i = 0; i < synth.getNumVoices(); ++i)
        if (auto* v = dynamic_cast<SynthVoice*>(synth.getVoice(i)))
            v->prepare(sampleRate, samplesPerBlock, getTotalNumOutputChannels());
}

void AllSynthPluginAudioProcessor::releaseResources() {}

#ifndef JucePlugin_PreferredChannelConfigurations
bool AllSynthPluginAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const
{
#if JucePlugin_IsMidiEffect
    juce::ignoreUnused(layouts);
    return true;
#else
    // Must have same number of input and output channels
    if (layouts.getMainOutputChannelSet() != juce::AudioChannelSet::mono() &&
        layouts.getMainOutputChannelSet() != juce::AudioChannelSet::stereo())
        return false;

#if ! JucePlugin_IsSynth
    if (layouts.getMainOutputChannelSet() != layouts.getMainInputChannelSet())
        return false;
#endif
    return true;
#endif
}
#endif

//==============================================================================
void AllSynthPluginAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midiMessages)
{
    juce::ScopedNoDenormals noDenormals;
    buffer.clear();

    synth.renderNextBlock(buffer, midiMessages, 0, buffer.getNumSamples());
}

//==============================================================================
juce::AudioProcessorEditor* AllSynthPluginAudioProcessor::createEditor()
{
    return new AllSynthPluginAudioProcessorEditor(*this);
}

void AllSynthPluginAudioProcessor::getStateInformation(juce::MemoryBlock& destData)
{
    auto state = parameters.copyState();
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, destData);
}

void AllSynthPluginAudioProcessor::setStateInformation(const void* data, int sizeInBytes)
{
    std::unique_ptr<juce::XmlElement> xml(getXmlFromBinary(data, sizeInBytes));
    if (xml && xml->hasTagName(parameters.state.getType()))
        parameters.replaceState(juce::ValueTree::fromXml(*xml));
}

//==============================================================================
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new AllSynthPluginAudioProcessor();
} 