#include <JuceHeader.h>
#include <array>
#include <cmath>

class SynthVoice : public juce::SynthesiserVoice
{
public:
    SynthVoice(juce::AudioProcessorValueTreeState& vts);

    //==============================================================================
    bool canPlaySound(juce::SynthesiserSound* sound) override;

    void startNote(int midiNoteNumber, float velocity, juce::SynthesiserSound*, int currentPitchWheelPosition) override;
    void stopNote(float velocity, bool allowTailOff) override;

    void pitchWheelMoved(int) override {}
    void controllerMoved(int, int) override {}

    void renderNextBlock(juce::AudioBuffer<float>&, int startSample, int numSamples) override;

    void prepare(double sampleRate, int samplesPerBlock, int outputChannels);

    enum
    {
        gainIndex,
        filterIndex,
        shaperIndex
    };

private:
    //==============================================================================
    float computeOscSample();
    void updateParams();

    // Members
    juce::AudioProcessorValueTreeState& parameters;

    // Internal audio util objects: Gain -> LadderFilter -> WaveShaper
    juce::dsp::ProcessorChain<juce::dsp::Gain<float>, juce::dsp::LadderFilter<float>, juce::dsp::WaveShaper<float>> filterChain;
    juce::dsp::StateVariableTPTFilter<float> svFilter;

    // Smoothed parameters
    juce::LinearSmoothedValue<float> cutoffSmoothed   { 20000.0f };
    juce::LinearSmoothedValue<float> resonanceSmoothed{     0.7f };

    int currentModel = 0;   // 0=minimoog 1=prodigy 2=arp2600 3=odyssey
                            // 4=cs80 5=jupiter-4 6=ms-20 7=polymoog 8=ob-x
                            // 9=prophet‑5 10=taurus 11=model d
                            // 12=sh‑101 13=juno‑60 14=monopoly
                            // 15=voyager 16=prophet‑6 17=jupiter‑8 18=polysix 19=matrix‑12
                            // 20=ppg wave 21=ob‑6 22=dx7 23=virus 24=d‑50
    juce::ADSR adsr;
    juce::ADSR::Parameters adsrParams;

    double currentSampleRate = 44100.0;

    // Oscillator phase
    double phase = 0.0;
    float triangleIntegrator = 0.0f;   // per‐voice integrator for triangle

    // NEW -----------------------------------------------------------------------
    double phase2 = 0.0;                  // 2nd oscillator
    float  triangleIntegrator2 = 0.0f;
    double lfoPhase = 0.0;                // LFO phase
    // ---------------------------------------------------------------------------

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(SynthVoice)
}; 