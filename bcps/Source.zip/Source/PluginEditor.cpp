#include "PluginProcessor.h"
#include "PluginEditor.h"

AllSynthPluginAudioProcessorEditor::AllSynthPluginAudioProcessorEditor(AllSynthPluginAudioProcessor& p)
    : AudioProcessorEditor(&p), processor(p)
{
    auto& vts = processor.getValueTreeState();

    // --- Envelope Section ---
    attackSlider.setSliderStyle(juce::Slider::SliderStyle::RotaryVerticalDrag);
    attackSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 20);
    addAndMakeVisible(attackSlider);
    attackLabel.setText("Attack", juce::dontSendNotification);
    attackLabel.attachToComponent(&attackSlider, false);
    attackLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(attackLabel);
    attackAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts, "ATTACK", attackSlider);

    decaySlider.setSliderStyle(juce::Slider::SliderStyle::RotaryVerticalDrag);
    decaySlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 20);
    addAndMakeVisible(decaySlider);
    decayLabel.setText("Decay", juce::dontSendNotification);
    decayLabel.attachToComponent(&decaySlider, false);
    decayLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(decayLabel);
    decayAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts, "DECAY", decaySlider);

    sustainSlider.setSliderStyle(juce::Slider::SliderStyle::RotaryVerticalDrag);
    sustainSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 20);
    addAndMakeVisible(sustainSlider);
    sustainLabel.setText("Sustain", juce::dontSendNotification);
    sustainLabel.attachToComponent(&sustainSlider, false);
    sustainLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(sustainLabel);
    sustainAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts, "SUSTAIN", sustainSlider);

    releaseSlider.setSliderStyle(juce::Slider::SliderStyle::RotaryVerticalDrag);
    releaseSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 20);
    addAndMakeVisible(releaseSlider);
    releaseLabel.setText("Release", juce::dontSendNotification);
    releaseLabel.attachToComponent(&releaseSlider, false);
    releaseLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(releaseLabel);
    releaseAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts, "RELEASE", releaseSlider);

    // --- Filter Section ---
    cutoffSlider.setSliderStyle(juce::Slider::SliderStyle::RotaryVerticalDrag);
    cutoffSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 20);
    addAndMakeVisible(cutoffSlider);
    cutoffLabel.setText("Cutoff", juce::dontSendNotification);
    cutoffLabel.attachToComponent(&cutoffSlider, false);
    cutoffLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(cutoffLabel);
    cutoffAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts, "CUTOFF", cutoffSlider);

    resonanceSlider.setSliderStyle(juce::Slider::SliderStyle::RotaryVerticalDrag);
    resonanceSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 20);
    addAndMakeVisible(resonanceSlider);
    resonanceLabel.setText("Resonance", juce::dontSendNotification);
    resonanceLabel.attachToComponent(&resonanceSlider, false);
    resonanceLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(resonanceLabel);
    resonanceAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts, "RESONANCE", resonanceSlider);

    // --- Oscillator Section ---
    waveformBox.addItemList({"Saw", "Square", "Pulse", "Triangle"}, 1);
    addAndMakeVisible(waveformBox);
    waveformLabel.setText("Waveform", juce::dontSendNotification);
    waveformLabel.attachToComponent(&waveformBox, false);
    waveformLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(waveformLabel);
    waveformAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(vts, "WAVEFORM", waveformBox);

    pulseWidthSlider.setSliderStyle(juce::Slider::SliderStyle::LinearHorizontal);
    pulseWidthSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 20);
    // Initially hide pulse width, only show if Square is selected
    // pulseWidthSlider.setVisible(false); // We'll handle visibility later if needed
    addAndMakeVisible(pulseWidthSlider);
    pulseWidthLabel.setText("Pulse Width", juce::dontSendNotification);
    pulseWidthLabel.attachToComponent(&pulseWidthSlider, false);
    pulseWidthLabel.setJustificationType(juce::Justification::centredBottom);
    // pulseWidthLabel.setVisible(false); // We'll handle visibility later if needed
    addAndMakeVisible(pulseWidthLabel);
    pulseWidthAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(vts, "PULSE_WIDTH", pulseWidthSlider);

    // --- Model Section ---
    modelBox.addItemList(
        {"Minimoog","Prodigy","ARP 2600","Odyssey",
         "CS-80","Jupiter-4","MS-20","Polymoog","OB-X",
         "Prophet-5","Taurus","Model D",
         "SH-101","Juno-60","MonoPoly"},
        1);
    addAndMakeVisible(modelBox);
    modelLabel.setText("Synth Model", juce::dontSendNotification);
    modelLabel.attachToComponent(&modelBox, false); // Attach above
    modelLabel.setJustificationType(juce::Justification::centredBottom);
    addAndMakeVisible(modelLabel);
    modelAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(vts, "MODEL", modelBox); // Changed ID


    // Set editor size
    setSize(600, 400); // Adjust size as needed
}

// Destructor is defaulted in the header

void AllSynthPluginAudioProcessorEditor::paint(juce::Graphics& g)
{
    // Fill the background
    g.fillAll(getLookAndFeel().findColour(juce::ResizableWindow::backgroundColourId));

    // Optional: Draw some text or decorations
    g.setColour(juce::Colours::white);
    g.setFont(15.0f);
    // g.drawFittedText("AllSynth v1.0", getLocalBounds(), juce::Justification::centredTop, 1);
}

void AllSynthPluginAudioProcessorEditor::resized()
{
    // Define the layout areas
    auto bounds = getLocalBounds().reduced(10); // Add some margin

    auto topArea = bounds.removeFromTop(bounds.getHeight() / 3);
    auto midArea = bounds.removeFromTop(bounds.getHeight() / 2); // Middle half of remaining
    auto bottomArea = bounds;                                 // Rest is bottom

    // --- Top Area: Model and Oscillator ---
    auto modelArea = topArea.removeFromLeft(topArea.getWidth() / 3);
    auto oscArea = topArea; // Remaining space in top area

    // Model layout
    modelBox.setBounds(modelArea.reduced(10, 30)); // Reduce for label space
    // Waveform layout
    waveformBox.setBounds(oscArea.removeFromLeft(oscArea.getWidth() / 2).reduced(10, 30));
    // Pulse width layout
    pulseWidthSlider.setBounds(oscArea.reduced(10, 30));


    // --- Mid Area: Filter ---
    auto filterArea = midArea;
    auto cutoffArea = filterArea.removeFromLeft(filterArea.getWidth() / 2);
    auto resonanceArea = filterArea;

    cutoffSlider.setBounds(cutoffArea.reduced(20));
    resonanceSlider.setBounds(resonanceArea.reduced(20));


    // --- Bottom Area: Envelope ---
    auto envArea = bottomArea;
    const int numEnvSliders = 4;
    auto sliderWidth = envArea.getWidth() / numEnvSliders;

    attackSlider.setBounds(envArea.removeFromLeft(sliderWidth).reduced(20));
    decaySlider.setBounds(envArea.removeFromLeft(sliderWidth).reduced(20));
    sustainSlider.setBounds(envArea.removeFromLeft(sliderWidth).reduced(20));
    releaseSlider.setBounds(envArea.removeFromLeft(sliderWidth).reduced(20));

    // Labels are attached, so their positions are relative to their components
}


